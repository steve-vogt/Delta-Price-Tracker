#!/usr/bin/env python3
"""
Delta Flight Tracker - Web UI v7
- Toast notifications instead of popups
- Screenshot capture and display
- Email/scheduling configuration
- Per-flight scheduling options
- Fixed Delta links

Run: python web_ui.py
Open: http://deltapricetracker.local:5000
"""

import sqlite3
import subprocess
import smtplib
import json
import base64
import logging
import re
import csv
import io
import os
import sys
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode
import time
from flask import Flask, render_template_string, request, redirect, url_for, jsonify, send_file, Response
from functools import wraps
from collections import defaultdict
from threading import Lock, Thread

# =============================================================================
# BASE PATH DETECTION FOR .EXE COMPATIBILITY
# =============================================================================

if getattr(sys, 'frozen', False):
    # Running as .exe - use executable directory
    BASE_PATH = Path(os.path.dirname(sys.executable))
else:
    # Running as script - use script directory
    BASE_PATH = Path(__file__).parent

# =============================================================================
# VERSION & UPDATE CHECK
# =============================================================================

APP_VERSION = "2.4.0"
GITHUB_REPO = "steve-vogt/Delta-Price-Tracker"
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"

# =============================================================================
# SECURITY & PERFORMANCE CONSTANTS
# =============================================================================

# Security
MAX_FILE_UPLOAD_SIZE = 10 * 1024 * 1024  # 10MB
MAX_IMPORT_FLIGHTS = 1000  # Max flights to import at once
RATE_LIMIT_REQUESTS = 100  # Max requests per window
RATE_LIMIT_WINDOW = 3600  # 1 hour in seconds

# Performance
DB_CONNECTION_TIMEOUT = 30  # seconds
SUBPROCESS_TIMEOUT = 300  # 5 minutes
SETTINGS_CACHE_TTL = 300  # 5 minutes
MAX_HISTORY_RECORDS = 1000  # Limit history queries

# Data limits
MAX_SCREENSHOT_RETENTION_DAYS = 365
MAX_BACKUP_RETENTION_DAYS = 30
MAX_SCREENSHOTS_PER_FLIGHT = 100

# Validation
MIN_PRICE = 1
MAX_PRICE = 999999
VALID_AIRPORT_CODE_PATTERN = r'^[A-Z]{3}$'

# =============================================================================
# FLASK APP SETUP WITH SECURITY
# =============================================================================

DB_PATH = BASE_PATH / "flights.db"
SETTINGS_FILE = BASE_PATH / "settings.json"
SCREENSHOTS_DIR = BASE_PATH / "screenshots"
app = Flask(__name__)

# Generate secure SECRET_KEY for sessions
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY') or base64.b64encode(os.urandom(24)).decode()
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_UPLOAD_SIZE

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(BASE_PATH / 'tracker.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# RATE LIMITING
# =============================================================================

rate_limit_store = defaultdict(list)
rate_limit_lock = Lock()

def rate_limit(max_requests=RATE_LIMIT_REQUESTS, window=RATE_LIMIT_WINDOW):
    """Rate limiting decorator."""
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            now = time.time()
            # Use IP address as key (in production, use user ID)
            key = request.remote_addr
            
            with rate_limit_lock:
                # Clean old requests
                rate_limit_store[key] = [req_time for req_time in rate_limit_store[key] 
                                         if now - req_time < window]
                
                # Check limit
                if len(rate_limit_store[key]) >= max_requests:
                    return jsonify({
                        'success': False,
                        'error': f'Rate limit exceeded. Max {max_requests} requests per {window//60} minutes.'
                    }), 429
                
                # Record this request
                rate_limit_store[key].append(now)
            
            return f(*args, **kwargs)
        return wrapped
    return decorator

# =============================================================================
# SETTINGS CACHE
# =============================================================================

_settings_cache = {'data': None, 'timestamp': 0}
_settings_cache_lock = Lock()

def load_settings():
    """Load settings with caching."""
    with _settings_cache_lock:
        now = time.time()
        if _settings_cache['data'] and (now - _settings_cache['timestamp']) < SETTINGS_CACHE_TTL:
            return _settings_cache['data'].copy()
        
        try:
            if SETTINGS_FILE.exists():
                settings = json.loads(SETTINGS_FILE.read_text())
            else:
                settings = DEFAULT_SETTINGS.copy()
            
            # Merge with defaults for any missing keys
            for key, value in DEFAULT_SETTINGS.items():
                settings.setdefault(key, value)
            
            _settings_cache['data'] = settings
            _settings_cache['timestamp'] = now
            return settings.copy()
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
            return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    """Save settings and invalidate cache."""
    try:
        SETTINGS_FILE.write_text(json.dumps(settings, indent=2))
        with _settings_cache_lock:
            _settings_cache['data'] = None  # Invalidate cache
        logger.info("Settings saved successfully")
        return True
    except Exception as e:
        logger.error(f"Error saving settings: {e}")
        return False

# Ensure screenshots dir exists
SCREENSHOTS_DIR.mkdir(exist_ok=True)

# Cache-busting: prevent browser from caching old versions
@app.after_request
def add_no_cache_headers(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# =============================================================================
# VALIDATION FUNCTIONS
# =============================================================================

def validate_airport_code(code):
    """Validate 3-letter airport code."""
    if not code or len(code) != 3:
        return False
    return bool(re.match(VALID_AIRPORT_CODE_PATTERN, code.upper()))

def validate_price(price):
    """Validate price is reasonable."""
    try:
        p = float(price)
        return MIN_PRICE <= p <= MAX_PRICE
    except (ValueError, TypeError):
        return False

def validate_date(date_str):
    """Validate date format and not in past."""
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
        return date.date() >= datetime.now().date()
    except (ValueError, TypeError):
        return False

def build_time_string(form):
    """Build a normalized time string from form fields (dep_hour, dep_min, dep_ampm).
    Returns format like '6:45am' or '' if no time specified."""
    hour = form.get('dep_hour', '').strip()
    minute = form.get('dep_min', '').strip()
    ampm = form.get('dep_ampm', '').strip().lower()
    
    # Also check for legacy single field (for imports/API)
    legacy = form.get('dep_time', '').strip()
    if legacy and not hour:
        # Normalize legacy format: "7:00 AM" -> "7:00am", "7 am" -> "7:00am"
        legacy = legacy.lower().replace(' ', '').replace('.', '')
        # Handle formats like "7am" -> "7:00am"
        if legacy and not ':' in legacy:
            for suffix in ['am', 'pm']:
                if legacy.endswith(suffix):
                    legacy = legacy[:-2] + ':00' + suffix
                    break
        return legacy
    
    if not hour or not minute or not ampm:
        return ''
    
    try:
        h = int(hour)
        if h < 1 or h > 12:
            return ''
    except ValueError:
        return ''
    
    return f"{h}:{minute}{ampm}"

def sanitize_filename(filename):
    """Sanitize filename to prevent path traversal."""
    # Remove any directory separators and parent references
    filename = os.path.basename(filename)
    filename = filename.replace('..', '').replace('/', '').replace('\\', '')
    # Only allow alphanumeric, dash, underscore, and dot
    filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
    return filename[:255]  # Limit length

# =============================================================================
# SETTINGS
# =============================================================================

DEFAULT_SETTINGS = {
    "email_from": "",
    "email_password": "",
    "email_to": "",
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "schedule_enabled": True,
    "schedule_time": "03:00",  # Single daily check time (3 AM recommended - prices update overnight)
    "stagger_minutes": 20,  # Minutes between each flight check (bot detection)
    "max_active_flights": 8,  # Max flights to track (bot detection limit)
    # Browser settings
    "use_headless_mode": True,  # True = invisible (headless), False = show browser window
    # Display preferences
    "time_format_24h": False,  # False = 12-hour (AM/PM), True = 24-hour
    # Price alert thresholds
    "price_alert_min_dollars": 0,  # Minimum dollar drop to alert (0 = any drop)
    "price_alert_min_percent": 0,  # Minimum percent drop to alert (0 = any drop)
    # View preferences
    "show_archived": False,
    # Screenshot management
    "screenshot_retention_days": 30,  # Auto-delete screenshots older than this
    "max_screenshots_per_flight": 50,  # Keep only last N screenshots per flight
    # Database backup
    "auto_backup_enabled": True,  # Auto-backup database daily
    "backup_retention_days": 7,  # Keep last N days of backups
    # Departure reminders
    "reminder_days_before": [7, 2],  # Send reminder emails X days before departure
    "reminders_enabled": False,
    # Duplicate detection
    "warn_on_duplicate": True,  # Warn before adding duplicate flights
}

MAX_FLIGHTS_LIMIT = 8  # Hard limit for bot detection

def should_send_alert(old_price, new_price):
    """Check if price drop meets threshold requirements."""
    if not old_price or new_price >= old_price:
        return False
    
    settings = load_settings()
    price_drop = old_price - new_price
    percent_drop = (price_drop / old_price) * 100
    
    min_dollars = settings.get('price_alert_min_dollars', 0)
    min_percent = settings.get('price_alert_min_percent', 0)
    
    # Must meet dollar threshold OR percent threshold (if set)
    dollar_ok = min_dollars == 0 or price_drop >= min_dollars
    percent_ok = min_percent == 0 or percent_drop >= min_percent
    
    return dollar_ok and percent_ok

def send_email(subject, body, settings=None, screenshot_path=None, booking_url=None):
    if settings is None:
        settings = load_settings()
    email_from = settings.get('email_from', '')
    email_password = settings.get('email_password', '')
    email_to = settings.get('email_to', '')
    
    if not email_from or not email_password or not email_to:
        return False
    try:
        msg = MIMEMultipart()
        msg['From'], msg['To'], msg['Subject'] = email_from, email_to, subject
        
        # Add booking URL to body if provided
        email_body = body
        if booking_url:
            email_body += f"\n\n🔗 Book this flight:\n{booking_url}"
        
        msg.attach(MIMEText(email_body, 'plain'))
        
        # Attach screenshot if provided
        if screenshot_path and Path(screenshot_path).exists():
            try:
                with open(screenshot_path, 'rb') as f:
                    img = MIMEImage(f.read())
                    img.add_header('Content-Disposition', 'attachment', filename='price_screenshot.png')
                    msg.attach(img)
            except Exception as e:
                print(f"Could not attach screenshot: {e}")
        
        server = smtplib.SMTP(settings.get('smtp_server', 'smtp.gmail.com'), 
                               settings.get('smtp_port', 587))
        server.starttls()
        server.login(email_from, email_password)
        server.sendmail(email_from, email_to, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

# =============================================================================
# DATABASE
# =============================================================================

def init_db():
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS flights (
        id INTEGER PRIMARY KEY, origin TEXT, destination TEXT,
        dep_date TEXT, ret_date TEXT, dep_time TEXT DEFAULT '',
        search_miles INTEGER DEFAULT 0, exclude_basic INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1, scheduled INTEGER DEFAULT 1,
        last_price REAL, lowest_price REAL,
        last_checked TEXT, created TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY, flight_id INTEGER, price REAL,
        checked_at TEXT, check_type TEXT DEFAULT 'manual', 
        error TEXT, screenshot TEXT
    )''')
    
    # Templates table for saved flight routes
    c.execute('''CREATE TABLE IF NOT EXISTS templates (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        origin TEXT NOT NULL,
        destination TEXT NOT NULL,
        dep_time TEXT DEFAULT '',
        search_miles INTEGER DEFAULT 0,
        exclude_basic INTEGER DEFAULT 0,
        notes TEXT DEFAULT '',
        created TEXT NOT NULL
    )''')
    
    # System status table for tracking operations
    c.execute('''CREATE TABLE IF NOT EXISTS system_status (
        id INTEGER PRIMARY KEY,
        last_auto_check TEXT,
        last_backup TEXT,
        last_screenshot_cleanup TEXT,
        last_reminder_check TEXT,
        scheduler_status TEXT DEFAULT 'stopped'
    )''')
    
    # Initialize system_status if empty
    c.execute('SELECT COUNT(*) FROM system_status')
    if c.fetchone()[0] == 0:
        c.execute('''INSERT INTO system_status (last_auto_check, scheduler_status) 
                     VALUES (?, ?)''', (None, 'stopped'))
    
    # System alerts table for tracking connection issues
    c.execute('''CREATE TABLE IF NOT EXISTS system_alerts (
        id INTEGER PRIMARY KEY,
        alert_type TEXT NOT NULL,
        message TEXT,
        created_at TEXT NOT NULL,
        dismissed INTEGER DEFAULT 0
    )''')
    
    # Add new columns if missing
    try:
        c.execute('ALTER TABLE flights ADD COLUMN scheduled INTEGER DEFAULT 1')
    except:
        pass
    try:
        c.execute('ALTER TABLE price_history ADD COLUMN screenshot TEXT')
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN archived INTEGER DEFAULT 0')
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN notes TEXT DEFAULT ""')
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN highest_price REAL')
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN reminder_sent TEXT')  # Track which reminders sent
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN paid_price REAL')  # Price user paid
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN paid_miles INTEGER')  # Miles user spent
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN alert_below_paid INTEGER DEFAULT 0')  # Only alert if below paid
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN claimed_savings REAL')  # Savings user actually claimed/rebooked
    except:
        pass
    try:
        c.execute('ALTER TABLE flights ADD COLUMN claimed_at TEXT')  # When savings were claimed
    except:
        pass
    
    try:
        c.execute('ALTER TABLE flights ADD COLUMN sort_order INTEGER DEFAULT 0')  # Manual sort order
    except:
        pass
    
    # Create indexes for better performance
    c.execute('CREATE INDEX IF NOT EXISTS idx_flights_active ON flights(active, archived)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_flights_dates ON flights(dep_date, ret_date)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_price_history_flight ON price_history(flight_id, checked_at)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_flights_scheduled ON flights(scheduled, active, archived)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_templates_route ON templates(origin, destination)')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized with all tables, columns and indexes")


def get_flights():
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''SELECT id, origin, destination as dest, dep_date, ret_date, dep_time,
                 search_miles as miles, exclude_basic, active, scheduled, archived, notes,
                 last_price as price, lowest_price as lowest, highest_price as highest, last_checked,
                 paid_price, paid_miles, alert_below_paid, claimed_savings, claimed_at,
                 COALESCE(sort_order, 0) as sort_order
                 FROM flights ORDER BY archived, sort_order, dep_date''')
    flights = [dict(r) for r in c.fetchall()]
    conn.close()
    return flights

def get_flight(fid):
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''SELECT id, origin, destination as dest, dep_date, ret_date, dep_time,
                 search_miles as miles, exclude_basic, active, scheduled, archived, notes,
                 paid_price, paid_miles, alert_below_paid, claimed_savings, claimed_at,
                 last_price as price, lowest_price as lowest, highest_price as highest, last_checked
                 FROM flights WHERE id=?''', (fid,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def get_history(limit=30):
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''SELECT ph.id, ph.price, ph.checked_at, ph.check_type, ph.error, ph.screenshot,
                 f.origin, f.destination as dest, f.search_miles as miles, f.dep_date
                 FROM price_history ph JOIN flights f ON ph.flight_id = f.id
                 ORDER BY ph.id DESC LIMIT ?''', (limit,))
    history = [dict(r) for r in c.fetchall()]
    conn.close()
    return history

def get_statistics():
    """Calculate statistics from flight data."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    
    stats = {}
    
    # Total active flights
    c.execute('SELECT COUNT(*) FROM flights WHERE archived = 0')
    stats['total_flights'] = c.fetchone()[0]
    
    # Total potential savings (highest - lowest for each flight)
    c.execute('''SELECT SUM(highest_price - lowest_price) 
                 FROM flights 
                 WHERE highest_price IS NOT NULL AND lowest_price IS NOT NULL AND archived = 0''')
    result = c.fetchone()[0]
    stats['total_savings'] = result if result else 0
    
    # Total claimed/actual savings
    c.execute('''SELECT SUM(claimed_savings) FROM flights WHERE claimed_savings IS NOT NULL''')
    result = c.fetchone()[0]
    stats['claimed_savings'] = result if result else 0
    
    # Average savings per flight
    c.execute('''SELECT AVG(highest_price - lowest_price) 
                 FROM flights 
                 WHERE highest_price IS NOT NULL AND lowest_price IS NOT NULL AND archived = 0''')
    result = c.fetchone()[0]
    stats['avg_savings'] = result if result else 0
    
    # Total price checks
    c.execute('SELECT COUNT(*) FROM price_history')
    stats['total_checks'] = c.fetchone()[0]
    
    # Archived flights count
    c.execute('SELECT COUNT(*) FROM flights WHERE archived = 1')
    stats['archived_count'] = c.fetchone()[0]
    
    # Best deal ever found
    c.execute('''SELECT origin, destination, highest_price, lowest_price, 
                 (highest_price - lowest_price) as savings
                 FROM flights 
                 WHERE highest_price IS NOT NULL AND lowest_price IS NOT NULL AND archived = 0
                 ORDER BY savings DESC LIMIT 1''')
    row = c.fetchone()
    if row:
        stats['best_deal'] = {
            'route': f"{row[0]}→{row[1]}",
            'saved': row[4],
            'was': row[2],
            'now': row[3]
        }
    else:
        stats['best_deal'] = None
    
    conn.close()
    return stats

# =============================================================================
# SYSTEM ALERTS (Connection Issues, etc.)
# =============================================================================

def add_system_alert(alert_type, message):
    """Add a system alert (e.g., connection failure)."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    now = datetime.now().isoformat()
    c.execute('INSERT INTO system_alerts (alert_type, message, created_at) VALUES (?, ?, ?)',
              (alert_type, message, now))
    conn.commit()
    conn.close()

def get_active_alerts():
    """Get undismissed alerts from the last 24 hours."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    # Get alerts from last 24 hours that haven't been dismissed
    cutoff = (datetime.now() - timedelta(hours=24)).isoformat()
    c.execute('''SELECT * FROM system_alerts 
                 WHERE dismissed = 0 AND created_at > ?
                 ORDER BY created_at DESC LIMIT 5''', (cutoff,))
    alerts = [dict(row) for row in c.fetchall()]
    conn.close()
    return alerts

def get_connection_failure_count():
    """Count recent connection failures."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    cutoff = (datetime.now() - timedelta(hours=24)).isoformat()
    c.execute('''SELECT COUNT(*) FROM system_alerts 
                 WHERE alert_type = 'connection_failure' AND created_at > ? AND dismissed = 0''', (cutoff,))
    count = c.fetchone()[0]
    conn.close()
    return count

def dismiss_alert(alert_id):
    """Dismiss an alert by ID."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('UPDATE system_alerts SET dismissed = 1 WHERE id = ?', (alert_id,))
    conn.commit()
    conn.close()

def dismiss_all_alerts():
    """Dismiss all alerts."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('UPDATE system_alerts SET dismissed = 1')
    conn.commit()
    conn.close()

def clear_old_alerts():
    """Clear alerts older than 7 days."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    cutoff = (datetime.now() - timedelta(days=7)).isoformat()
    c.execute('DELETE FROM system_alerts WHERE created_at < ?', (cutoff,))
    conn.commit()
    conn.close()

# =============================================================================
# UPDATE CHECK
# =============================================================================

def check_for_updates():
    """Check GitHub for newer version."""
    try:
        import urllib.request
        import json
        
        req = urllib.request.Request(
            GITHUB_API_URL,
            headers={'User-Agent': 'DeltaFlightTracker'}
        )
        
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            latest_version = data.get('tag_name', '').lstrip('v')
            download_url = data.get('html_url', '')
            release_notes = data.get('body', '')[:200]  # First 200 chars
            
            # Compare versions
            def parse_version(v):
                try:
                    return tuple(int(x) for x in v.split('.'))
                except:
                    return (0, 0, 0)
            
            current = parse_version(APP_VERSION)
            latest = parse_version(latest_version)
            
            if latest > current:
                return {
                    'update_available': True,
                    'current_version': APP_VERSION,
                    'latest_version': latest_version,
                    'download_url': download_url,
                    'release_notes': release_notes
                }
            else:
                return {
                    'update_available': False,
                    'current_version': APP_VERSION
                }
    except Exception as e:
        logger.debug(f"Update check failed: {e}")
        return {
            'update_available': False,
            'current_version': APP_VERSION,
            'error': str(e)
        }

# =============================================================================
# SYSTEM MANAGEMENT FUNCTIONS
# =============================================================================

def get_system_status():
    """Get current system status information."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('SELECT * FROM system_status WHERE id = 1')
    row = c.fetchone()
    conn.close()
    
    if not row:
        return {
            'last_auto_check': None,
            'last_backup': None,
            'last_screenshot_cleanup': None,
            'last_reminder_check': None,
            'scheduler_status': 'stopped'
        }
    
    return {
        'last_auto_check': row[1],
        'last_backup': row[2],
        'last_screenshot_cleanup': row[3],
        'last_reminder_check': row[4],
        'scheduler_status': row[5]
    }

def update_system_status(field, value):
    """Update a specific system status field. SECURE: Uses whitelist to prevent SQL injection."""
    # SECURITY: Whitelist allowed fields to prevent SQL injection
    allowed_fields = {
        'last_auto_check', 'last_backup', 'last_screenshot_cleanup',
        'last_reminder_check', 'scheduler_status'
    }
    
    if field not in allowed_fields:
        logger.error(f"Attempted to update invalid system_status field: {field}")
        raise ValueError(f"Invalid system status field: {field}")
    
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        # Safe now because field is validated against whitelist
        c.execute(f'UPDATE system_status SET {field} = ? WHERE id = 1', (value,))
        conn.commit()
        conn.close()
        logger.debug(f"Updated system_status.{field} = {value}")
    except Exception as e:
        logger.error(f"Error updating system_status.{field}: {e}")
        raise

def backup_database():
    """Create a backup of the database."""
    try:
        settings = load_settings()
        if not settings.get('auto_backup_enabled', True):
            return False
        
        backup_dir = BASE_PATH / "backups"
        backup_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f"flights_backup_{timestamp}.db"
        
        # Copy database file
        import shutil
        shutil.copy2(DB_PATH, backup_path)
        
        # Clean old backups
        retention_days = settings.get('backup_retention_days', 7)
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        
        for backup_file in backup_dir.glob("flights_backup_*.db"):
            try:
                # Parse timestamp from filename
                file_timestamp = backup_file.stem.split('_')[-2] + backup_file.stem.split('_')[-1]
                file_date = datetime.strptime(file_timestamp, "%Y%m%d%H%M%S")
                if file_date < cutoff_date:
                    backup_file.unlink()
                    logger.info(f"Deleted old backup: {backup_file.name}")
            except:
                pass
        
        update_system_status('last_backup', datetime.now().isoformat())
        logger.info(f"Database backed up to {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Backup failed: {e}")
        return False

def cleanup_screenshots():
    """Delete old screenshots based on retention settings."""
    try:
        settings = load_settings()
        retention_days = settings.get('screenshot_retention_days', 30)
        max_per_flight = settings.get('max_screenshots_per_flight', 50)
        
        if retention_days <= 0:
            return 0
        
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        cutoff_str = cutoff_date.strftime("%Y-%m-%d %H:%M:%S")
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        
        # Delete old screenshot records and files
        c.execute('''SELECT screenshot FROM price_history 
                     WHERE screenshot IS NOT NULL AND checked_at < ?''', (cutoff_str,))
        old_screenshots = [row[0] for row in c.fetchall()]
        
        deleted_count = 0
        for screenshot in old_screenshots:
            screenshot_path = SCREENSHOTS_DIR / screenshot
            if screenshot_path.exists():
                screenshot_path.unlink()
                deleted_count += 1
        
        c.execute('UPDATE price_history SET screenshot = NULL WHERE checked_at < ?', (cutoff_str,))
        
        # Also limit screenshots per flight
        if max_per_flight > 0:
            c.execute('SELECT DISTINCT flight_id FROM price_history WHERE screenshot IS NOT NULL')
            flight_ids = [row[0] for row in c.fetchall()]
            
            for flight_id in flight_ids:
                c.execute('''SELECT id, screenshot FROM price_history 
                            WHERE flight_id = ? AND screenshot IS NOT NULL 
                            ORDER BY checked_at DESC''', (flight_id,))
                screenshots = c.fetchall()
                
                if len(screenshots) > max_per_flight:
                    for screenshot_id, screenshot in screenshots[max_per_flight:]:
                        screenshot_path = SCREENSHOTS_DIR / screenshot
                        if screenshot_path.exists():
                            screenshot_path.unlink()
                            deleted_count += 1
                        c.execute('UPDATE price_history SET screenshot = NULL WHERE id = ?', (screenshot_id,))
        
        conn.commit()
        conn.close()
        
        update_system_status('last_screenshot_cleanup', datetime.now().isoformat())
        logger.info(f"Cleaned up {deleted_count} old screenshots")
        return deleted_count
    except Exception as e:
        logger.error(f"Screenshot cleanup failed: {e}")
        return 0

def check_duplicate_flight(origin, dest, dep_date):
    """Check if a flight with same route and date already exists."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('''SELECT id, active, archived FROM flights 
                 WHERE origin = ? AND destination = ? AND dep_date = ?''',
              (origin.upper(), dest.upper(), dep_date))
    result = c.fetchone()
    conn.close()
    
    if result:
        return {
            'exists': True,
            'id': result[0],
            'active': bool(result[1]),
            'archived': bool(result[2])
        }
    return {'exists': False}

def get_price_history_data(flight_id):
    """Get price history for charting."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('''SELECT checked_at, price FROM price_history 
                 WHERE flight_id = ? AND error IS NULL AND price IS NOT NULL
                 ORDER BY checked_at ASC''', (flight_id,))
    history = [{'date': row[0], 'price': row[1]} for row in c.fetchall()]
    conn.close()
    return history

# =============================================================================
# TEMPLATE MANAGEMENT
# =============================================================================

def get_templates():
    """Get all saved flight templates."""
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''SELECT id, name, origin, destination as dest, dep_time, 
                 search_miles as miles, exclude_basic, notes, created 
                 FROM templates ORDER BY created DESC''')
    templates = [dict(r) for r in c.fetchall()]
    conn.close()
    return templates

def create_template(name, origin, dest, dep_time='', search_miles=0, exclude_basic=0, notes=''):
    """Create a new flight template."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('''INSERT INTO templates (name, origin, destination, dep_time, search_miles, 
                     exclude_basic, notes, created) VALUES (?,?,?,?,?,?,?,?)''',
                  (name, origin.upper(), dest.upper(), dep_time, search_miles, exclude_basic, 
                   notes, datetime.now().isoformat()))
        template_id = c.lastrowid
        conn.commit()
        conn.close()
        logger.info(f"Created template: {name} ({origin}-{dest})")
        return template_id
    except Exception as e:
        logger.error(f"Error creating template: {e}")
        return None

def delete_template(template_id):
    """Delete a flight template."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('DELETE FROM templates WHERE id = ?', (template_id,))
        conn.commit()
        conn.close()
        logger.info(f"Deleted template {template_id}")
        return True
    except Exception as e:
        logger.error(f"Error deleting template: {e}")
        return False

# =============================================================================
# BULK OPERATIONS
# =============================================================================

def bulk_date_shift(flight_ids, days_offset):
    """Shift departure and return dates for multiple flights."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        updated = 0
        
        for flight_id in flight_ids:
            c.execute('SELECT dep_date, ret_date FROM flights WHERE id = ?', (flight_id,))
            row = c.fetchone()
            if not row:
                continue
            
            dep_date, ret_date = row
            new_dep = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=days_offset)).strftime("%Y-%m-%d")
            new_ret = None
            if ret_date:
                new_ret = (datetime.strptime(ret_date, "%Y-%m-%d") + timedelta(days=days_offset)).strftime("%Y-%m-%d")
            
            c.execute('UPDATE flights SET dep_date = ?, ret_date = ? WHERE id = ?',
                      (new_dep, new_ret, flight_id))
            updated += 1
        
        conn.commit()
        conn.close()
        logger.info(f"Bulk shifted {updated} flights by {days_offset} days")
        return updated
    except Exception as e:
        logger.error(f"Bulk date shift failed: {e}")
        return 0

# =============================================================================
# REMINDER SYSTEM
# =============================================================================

def check_departure_reminders():
    """Check for flights needing departure reminders."""
    try:
        settings = load_settings()
        if not settings.get('reminders_enabled', False):
            return 0
        
        reminder_days = settings.get('reminder_days_before', [7, 2])
        if not reminder_days:
            return 0
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        
        today = datetime.now().date()
        sent_count = 0
        
        for days_before in reminder_days:
            target_date = (today + timedelta(days=days_before)).strftime("%Y-%m-%d")
            
            # Find flights departing on target date that haven't been reminded
            c.execute('''SELECT id, origin, destination, dep_date, last_price, search_miles, reminder_sent
                         FROM flights 
                         WHERE dep_date = ? AND active = 1 AND archived = 0''', (target_date,))
            
            for row in c.fetchall():
                flight_id, origin, dest, dep_date, last_price, is_miles, reminder_sent = row
                
                # Check if this reminder already sent
                sent_reminders = reminder_sent.split(',') if reminder_sent else []
                reminder_key = f"{days_before}d"
                
                if reminder_key in sent_reminders:
                    continue
                
                # Send reminder email
                sym = "" if is_miles else "$"
                unit = " miles" if is_miles else ""
                price_str = f"{sym}{last_price:,.0f}{unit}" if last_price else "not checked yet"
                
                subject = f"✈️ Reminder: {origin}-{dest} departs in {days_before} days"
                body = f"""Flight Reminder:
                
Route: {origin} → {dest}
Departure: {dep_date} ({days_before} days away)
Current Price: {price_str}

This is a reminder to check prices one last time before your departure!
"""
                
                if send_email(subject, body):
                    # Mark reminder as sent
                    sent_reminders.append(reminder_key)
                    new_reminder_sent = ','.join(sent_reminders)
                    c.execute('UPDATE flights SET reminder_sent = ? WHERE id = ?', 
                             (new_reminder_sent, flight_id))
                    sent_count += 1
        
        conn.commit()
        conn.close()
        
        if sent_count > 0:
            update_system_status('last_reminder_check', datetime.now().isoformat())
            logger.info(f"Sent {sent_count} departure reminders")
        
        return sent_count
    except Exception as e:
        logger.error(f"Reminder check failed: {e}")
        return 0

# =============================================================================
# URL GENERATION
# =============================================================================

def generate_delta_url(origin, dest, dep_date, ret_date=None, use_miles=False, exclude_basic=False):
    """Generate Delta search URL that actually loads search results."""
    dep_dt = datetime.strptime(dep_date, "%Y-%m-%d")
    dep_formatted = dep_dt.strftime("%m/%d/%Y")
    
    params = {
        'action': 'findFlights',
        'tripType': 'ROUND_TRIP' if ret_date else 'ONE_WAY',
        'originCity': origin.upper(),
        'destinationCity': dest.upper(),
        'departureDate': dep_formatted,
        'departureTime': 'AT',
        'returnTime': 'AT',
        'paxCount': 1,
        'awardTravel': 'true' if use_miles else 'false',
    }
    
    if ret_date:
        ret_dt = datetime.strptime(ret_date, "%Y-%m-%d")
        params['returnDate'] = ret_dt.strftime("%m/%d/%Y")
    
    if exclude_basic and not use_miles:
        params['cabinFareClass'] = 'MAIN'
    
    return f"https://www.delta.com/flight-search/book-a-flight?{urlencode(params)}"

# =============================================================================
# BACKGROUND SCHEDULER
# =============================================================================

# Track last scheduled run to avoid duplicates
_scheduler_last_run_date = None
_scheduler_running = False
_scheduler_thread = None

def run_scheduled_checks():
    """Run the scheduled price checks (called by scheduler thread)."""
    global _scheduler_last_run_date
    
    try:
        logger.info("Scheduler: Starting scheduled price checks...")
        
        # Import tracker module
        import importlib
        sys.path.insert(0, str(BASE_PATH))
        
        if 'tracker' in sys.modules:
            import tracker
            importlib.reload(tracker)
        else:
            import tracker
        
        # Get flights to check
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Auto-expire past flights
        c.execute('UPDATE flights SET active=0 WHERE dep_date < ? AND active=1', (today,))
        conn.commit()
        
        # Get active scheduled flights
        c.execute('''SELECT id, origin, destination FROM flights 
                     WHERE active=1 AND scheduled=1 AND archived=0 AND dep_date >= ? 
                     ORDER BY dep_date''', (today,))
        flights = c.fetchall()
        conn.close()
        
        if not flights:
            logger.info("Scheduler: No active scheduled flights to check")
            return
        
        logger.info(f"Scheduler: Checking {len(flights)} flights...")
        
        settings = load_settings()
        use_headless = settings.get('use_headless_mode', True)
        
        checked = 0
        for flight in flights:
            fid = flight['id']
            origin = flight['origin']
            dest = flight['destination']
            
            try:
                logger.info(f"Scheduler: Checking {origin}->{dest} (id={fid})")
                result = tracker.check_flight_auto(fid, headless=use_headless, take_screenshot=True)
                
                if len(result) == 3:
                    price, error, screenshot_file = result
                else:
                    price, error = result
                    screenshot_file = None
                
                if price:
                    # Get old price for comparison
                    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
                    c = conn.cursor()
                    c.execute('SELECT last_price, lowest_price, highest_price FROM flights WHERE id=?', (fid,))
                    row = c.fetchone()
                    old_price = row[0] if row else None
                    lowest = row[1] if row else None
                    highest = row[2] if row else None
                    
                    # Update prices
                    new_lowest = min(price, lowest) if lowest else price
                    new_highest = max(price, highest) if highest else price
                    
                    c.execute('''UPDATE flights SET last_price=?, lowest_price=?, highest_price=?, last_checked=? 
                                 WHERE id=?''', (price, new_lowest, new_highest, datetime.now().isoformat(), fid))
                    
                    # Save to history
                    screenshot_data = None
                    if screenshot_file and Path(screenshot_file).exists():
                        with open(screenshot_file, 'rb') as f:
                            screenshot_data = f.read()
                    
                    c.execute('''INSERT INTO price_history (flight_id, price, checked_at, check_type, screenshot) 
                                 VALUES (?, ?, ?, 'auto', ?)''', (fid, price, datetime.now().isoformat(), screenshot_data))
                    conn.commit()
                    conn.close()
                    
                    # Check if we should send alert
                    if old_price and price < old_price and should_send_alert(old_price, price):
                        logger.info(f"Scheduler: Price drop! {origin}->{dest}: ${old_price} -> ${price}")
                        try:
                            send_email(
                                f"✈️ Price Drop: {origin}→{dest}",
                                f"Price dropped from ${old_price:,.0f} to ${price:,.0f}!",
                                settings,
                                screenshot_file
                            )
                        except Exception as e:
                            logger.error(f"Scheduler: Email failed: {e}")
                    
                    checked += 1
                    logger.info(f"Scheduler: {origin}->{dest} = ${price}")
                else:
                    logger.warning(f"Scheduler: {origin}->{dest} failed: {error}")
                    
            except Exception as e:
                logger.error(f"Scheduler: Error checking flight {fid}: {e}")
            
            # Delay between flights (jitter for anti-bot)
            if flight != flights[-1]:
                import random
                if random.random() < 0.2:
                    delay = random.uniform(25, 45)
                else:
                    delay = random.uniform(8, 25)
                logger.info(f"Scheduler: Waiting {delay:.0f}s before next flight...")
                time.sleep(delay)
        
        logger.info(f"Scheduler: Completed. Checked {checked}/{len(flights)} flights.")
        _scheduler_last_run_date = datetime.now().strftime("%Y-%m-%d")
        
    except Exception as e:
        logger.error(f"Scheduler: Error in run_scheduled_checks: {e}")
        import traceback
        traceback.print_exc()

def scheduler_loop():
    """Background thread that checks if it's time to run scheduled checks."""
    global _scheduler_last_run_date, _scheduler_running
    
    logger.info("Scheduler: Background scheduler started")
    _scheduler_running = True
    
    # Wait a bit for app to fully start
    time.sleep(10)
    
    while _scheduler_running:
        try:
            settings = load_settings()
            
            # Check if scheduling is enabled
            if not settings.get('schedule_enabled', False):
                time.sleep(60)
                continue
            
            # Get scheduled time
            schedule_time = settings.get('schedule_time', '03:00')
            
            # Parse schedule time
            try:
                sched_hour, sched_minute = map(int, schedule_time.split(':'))
            except:
                sched_hour, sched_minute = 3, 0
            
            now = datetime.now()
            current_date = now.strftime("%Y-%m-%d")
            
            # Check if we already ran today
            if _scheduler_last_run_date == current_date:
                time.sleep(60)
                continue
            
            # Check if it's time to run (within 5-minute window, with some jitter)
            # Add random jitter of 0-30 minutes to the scheduled time
            import random
            jitter_minutes = random.randint(0, 30)
            
            target_time = now.replace(hour=sched_hour, minute=sched_minute, second=0, microsecond=0)
            target_time = target_time + timedelta(minutes=jitter_minutes)
            
            # Run if we're past the target time (with jitter) but haven't run today
            if now >= target_time and _scheduler_last_run_date != current_date:
                logger.info(f"Scheduler: Time to run! Scheduled: {schedule_time}, Jitter: +{jitter_minutes}m, Now: {now.strftime('%H:%M')}")
                run_scheduled_checks()
            
            # Sleep for 60 seconds before checking again
            time.sleep(60)
            
        except Exception as e:
            logger.error(f"Scheduler: Error in scheduler_loop: {e}")
            time.sleep(60)
    
    logger.info("Scheduler: Background scheduler stopped")

def start_scheduler():
    """Start the background scheduler thread."""
    global _scheduler_thread, _scheduler_running
    
    if _scheduler_thread and _scheduler_thread.is_alive():
        logger.info("Scheduler: Already running")
        return
    
    _scheduler_running = True
    _scheduler_thread = Thread(target=scheduler_loop, daemon=True, name="PriceCheckScheduler")
    _scheduler_thread.start()
    logger.info("Scheduler: Started background scheduler thread")

def stop_scheduler():
    """Stop the background scheduler thread."""
    global _scheduler_running
    _scheduler_running = False
    logger.info("Scheduler: Stopping scheduler...")

# =============================================================================
# HTML TEMPLATE
# =============================================================================

HTML = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delta Flight Tracker</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        :root {
            --bg-primary: #0f0f1a;
            --bg-secondary: #1a1a2e;
            --bg-card: #16162a;
            --bg-input: #0d0d1a;
            --border-color: #2a2a4a;
            --border-light: #3a3a5a;
            --text-primary: #ffffff;
            --text-secondary: #a0a0c0;
            --text-muted: #6a6a8a;
            --accent-primary: #6366f1;
            --accent-secondary: #8b5cf6;
            --accent-green: #10b981;
            --accent-red: #ef4444;
            --accent-blue: #3b82f6;
            --accent-orange: #f59e0b;
            --accent-pink: #ec4899;
            --delta-red: #c41230;
            --gradient-primary: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            --gradient-green: linear-gradient(135deg, #10b981 0%, #34d399 100%);
            --gradient-blue: linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.4);
            --shadow-lg: 0 8px 40px rgba(0,0,0,0.5);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
            background: var(--bg-primary);
            background-image: radial-gradient(ellipse at top, #1a1a3e 0%, var(--bg-primary) 60%);
            min-height: 100vh; 
            color: var(--text-primary);
            font-size: 15px;
            line-height: 1.6;
        }
        
        .container { max-width: 1280px; margin: 0 auto; padding: 32px 24px; }
        
        h1 { 
            text-align: center; 
            margin-bottom: 32px; 
            font-size: 2.5em; 
            font-weight: 700;
            background: linear-gradient(135deg, #fff 0%, #a0a0ff 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        h1 .delta { 
            background: linear-gradient(135deg, #ff4466 0%, #c41230 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        h1 .version {
            font-size: 0.35em;
            font-weight: 500;
            background: var(--text-muted);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            vertical-align: middle;
        }
        
        /* Tabs */
        .tabs { 
            display: flex; 
            gap: 12px; 
            margin-bottom: 28px;
            background: var(--bg-card);
            padding: 8px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-color);
        }
        .tab { 
            flex: 1;
            padding: 14px 24px; 
            background: transparent;
            border: none;
            border-radius: var(--radius-md); 
            cursor: pointer; 
            color: var(--text-secondary);
            font-size: 1em;
            font-weight: 500;
            transition: all 0.25s ease;
            text-align: center;
        }
        .tab:hover { 
            background: var(--bg-secondary);
            color: var(--text-primary);
        }
        .tab.active { 
            background: var(--gradient-primary);
            color: #fff;
            box-shadow: var(--shadow-sm);
        }
        .tab-content { display: none; animation: fadeIn 0.3s ease; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        /* Cards */
        .card { 
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 28px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }
        .card:hover {
            border-color: var(--border-light);
            box-shadow: var(--shadow-md);
        }
        .card h2 { 
            font-size: 1.2em;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-color);
        }
        
        /* Forms */
        .form-row { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; }
        .form-group { display: flex; flex-direction: column; min-width: 120px; flex: 1; }
        .form-group label { 
            font-size: 0.9em;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
        }
        .form-group input, .form-group select { 
            padding: 14px 16px;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            background: var(--bg-input);
            color: var(--text-primary);
            font-size: 1em;
            font-family: inherit;
            transition: all 0.2s ease;
        }
        .form-group input:focus, .form-group select:focus { 
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
        }
        .form-group input::placeholder { color: var(--text-muted); }
        .form-group.wide { flex: 2; min-width: 240px; }
        
        /* Checkboxes */
        .checkbox-row { display: flex; gap: 28px; margin: 16px 0; flex-wrap: wrap; }
        .checkbox-row label { 
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95em;
            cursor: pointer;
            color: var(--text-secondary);
            transition: color 0.2s;
        }
        .checkbox-row label:hover { color: var(--text-primary); }
        .checkbox-row input[type="checkbox"] { 
            width: 20px;
            height: 20px;
            accent-color: var(--accent-primary);
            cursor: pointer;
        }
        
        /* Buttons */
        .btn { 
            padding: 12px 24px;
            border: none;
            border-radius: var(--radius-md);
            font-size: 0.95em;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-primary { 
            background: var(--gradient-primary);
            color: #fff;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
        }
        .btn-primary:hover { 
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
        }
        .btn-secondary { 
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }
        .btn-secondary:hover { 
            background: var(--border-color);
            border-color: var(--border-light);
        }
        .btn-danger { 
            background: transparent;
            color: var(--accent-red);
            border: 1px solid var(--accent-red);
            padding: 8px 14px;
        }
        .btn-danger:hover { 
            background: rgba(239, 68, 68, 0.15);
        }
        .btn-small { padding: 10px 14px; font-size: 0.85em; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none !important; }
        .btn-row { display: flex; gap: 12px; margin-top: 20px; flex-wrap: wrap; }
        
        /* Table */
        table { width: 100%; border-collapse: collapse; font-size: 0.95em; }
        thead { background: var(--bg-secondary); }
        th { 
            padding: 16px 12px;
            text-align: left;
            color: var(--text-muted);
            font-size: 0.85em;
            font-weight: 600;
        }
        th.sortable {
            cursor: pointer;
            user-select: none;
            transition: color 0.2s;
        }
        th.sortable:hover {
            color: var(--accent-blue);
        }
        th.sortable::after {
            content: ' ↕';
            opacity: 0.4;
            font-size: 0.8em;
        }
        th.sortable.sort-asc::after {
            content: ' ↑';
            opacity: 1;
            color: var(--accent-blue);
        }
        th.sortable.sort-desc::after {
            content: ' ↓';
            opacity: 1;
            color: var(--accent-blue);
        }
        .move-btns {
            display: flex;
            flex-direction: column;
            gap: 2px;
            margin-right: 8px;
        }
        .move-btn {
            padding: 2px 6px;
            font-size: 0.7em;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 4px;
            cursor: pointer;
            color: var(--text-muted);
            transition: all 0.2s;
        }
        .move-btn:hover {
            background: var(--accent-blue);
            color: white;
            border-color: var(--accent-blue);
        }
        td { 
            padding: 18px 12px;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }
        tr { transition: background 0.2s; }
        tr:hover { background: rgba(99, 102, 241, 0.05); }
        
        /* Route & Badges */
        .route { 
            font-weight: 700;
            font-size: 1.15em;
            letter-spacing: 0.5px;
        }
        .arrow { 
            color: var(--delta-red);
            margin: 0 6px;
            font-weight: 400;
        }
        .badge { 
            display: inline-flex;
            align-items: center;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.7em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .badge-cash { background: var(--gradient-green); color: #fff; }
        .badge-miles { background: var(--gradient-blue); color: #fff; }
        .badge-manual { background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%); color: #fff; }
        .badge-auto { background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%); color: #000; }
        .badge-scheduled { background: var(--accent-green); color: #fff; }
        .badge-skip { background: var(--bg-secondary); color: var(--text-muted); }
        
        /* Schedule Toggle Button */
        .toggle-btn {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            border: none;
            font-family: inherit;
        }
        .toggle-on {
            background: var(--accent-green);
            color: #fff;
        }
        .toggle-on:hover {
            background: #059669;
        }
        .toggle-off {
            background: var(--bg-secondary);
            color: var(--text-muted);
            border: 1px dashed var(--border-light);
        }
        .toggle-off:hover {
            background: var(--border-color);
            color: var(--text-primary);
            border-style: solid;
        }
        
        /* Prices */
        .price { font-weight: 700; font-size: 1.2em; }
        .price-cash { color: #34d399; }
        .price-miles { color: #60a5fa; }
        .price-lowest { color: var(--text-muted); font-size: 0.9em; font-weight: 500; }
        
        /* Actions */
        .actions { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
        .last-checked-inline { 
            font-size: 0.75em;
            color: var(--text-muted);
            margin-left: 10px;
            white-space: nowrap;
            background: var(--bg-secondary);
            padding: 4px 8px;
            border-radius: 6px;
        }
        .timestamp { color: var(--text-muted); font-size: 0.85em; }
        
        /* Toast Notifications */
        .toast-container { position: fixed; top: 24px; right: 24px; z-index: 2000; }
        .toast { 
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            padding: 18px 24px;
            margin-bottom: 12px;
            box-shadow: var(--shadow-lg);
            animation: slideIn 0.3s ease;
            min-width: 320px;
            display: flex;
            align-items: center;
            gap: 14px;
            backdrop-filter: blur(10px);
        }
        .toast.success { border-left: 4px solid var(--accent-green); }
        .toast.error { border-left: 4px solid var(--accent-red); }
        .toast.info { border-left: 4px solid var(--accent-blue); }
        .toast.warning { border-left: 4px solid var(--accent-orange); }
        .toast-icon { font-size: 1.5em; }
        .toast-content { flex: 1; }
        .toast-title { font-weight: 600; margin-bottom: 4px; }
        .toast-message { font-size: 0.9em; color: var(--text-secondary); }
        .toast-close { background: none; border: none; color: var(--text-muted); cursor: pointer; font-size: 1.3em; padding: 4px; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
        
        /* Progress Overlay */
        .progress-overlay { 
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 15, 26, 0.95);
            backdrop-filter: blur(8px);
            z-index: 1500;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .progress-overlay.active { display: flex; }
        .progress-plane { font-size: 5em; animation: fly 2s ease-in-out infinite; }
        @keyframes fly { 0%, 100% { transform: translateY(0) rotate(-5deg); } 50% { transform: translateY(-25px) rotate(5deg); } }
        .progress-text { margin-top: 24px; font-size: 1.4em; font-weight: 600; color: var(--text-primary); }
        .progress-subtext { color: var(--text-secondary); margin-top: 10px; font-size: 1em; }
        .progress-bar { 
            width: 320px;
            height: 8px;
            background: var(--bg-secondary);
            border-radius: 4px;
            margin-top: 28px;
            overflow: hidden;
        }
        .progress-fill { 
            height: 100%;
            background: var(--gradient-primary);
            width: 0%;
            transition: width 0.3s;
            border-radius: 4px;
        }
        
        /* Modal */
        .modal-overlay { 
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 15, 26, 0.9);
            backdrop-filter: blur(6px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.active { display: flex; }
        .modal { 
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-lg);
            padding: 32px;
            width: 90%;
            max-width: 420px;
            box-shadow: var(--shadow-lg);
            animation: modalIn 0.25s ease;
        }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .modal h3 { margin-bottom: 10px; font-size: 1.3em; color: var(--text-primary); }
        .modal p { color: var(--text-secondary); font-size: 0.95em; margin-bottom: 20px; }
        .modal input[type="number"] { 
            width: 100%;
            padding: 18px;
            font-size: 1.5em;
            text-align: center;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            background: var(--bg-input);
            color: var(--text-primary);
            margin-bottom: 20px;
            font-family: inherit;
        }
        .modal input:focus { border-color: var(--accent-primary); outline: none; }
        .modal-btns { display: flex; gap: 12px; justify-content: flex-end; }
        
        /* History */
        .history-item { 
            padding: 16px;
            margin-bottom: 8px;
            border-radius: var(--radius-md);
            background: var(--bg-secondary);
            transition: all 0.2s;
        }
        .history-item:hover { background: var(--border-color); }
        .history-item.has-screenshot-item { 
            border-left: 3px solid var(--accent-blue);
        }
        .history-main { 
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }
        .history-screenshot { display: none; margin-top: 16px; }
        .history-screenshot.visible { display: block; }
        .history-screenshot img { 
            max-width: 100%;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
        }
        .screenshot-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            background: var(--accent-blue);
            color: white;
            border-radius: 12px;
            font-size: 0.75em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            margin-left: 8px;
        }
        .screenshot-btn:hover {
            background: #2563eb;
            transform: scale(1.05);
        }
        .has-screenshot { color: var(--accent-blue); }
        
        .empty { 
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }
        .empty p:first-child { font-size: 1.1em; }
        
        .spinner { 
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #fff;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        
        .help-text { font-size: 0.85em; color: var(--text-muted); margin-top: 6px; }
        
        /* Donation payment links */
        a[href*="cash.app"] > div:hover,
        a[href*="paypal.me"] > div:hover,
        a[href*="venmo.com"] > div:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: var(--border-light);
        }
        
        /* Price change indicators */
        .price-change {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 0.85em;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 600;
        }
        .price-up {
            color: #ef4444;
            background: rgba(239, 68, 68, 0.1);
        }
        .price-down {
            color: #10b981;
            background: rgba(16, 185, 129, 0.1);
        }
        .price-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.75em;
            font-weight: 600;
            margin-left: 8px;
        }
        .badge-hot { 
            background: linear-gradient(135deg, #ff4466 0%, #ff6b88 100%); 
            color: white; 
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }
        .badge-rising { background: #fef3c7; color: #92400e; }
        .badge-good { background: #d1fae5; color: #065f46; }
        
        /* Statistics cards */
        .stat-card {
            text-align: center;
            padding: 24px;
            background: var(--bg-secondary);
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
            transition: all 0.3s;
        }
        .stat-card:hover {
            border-color: var(--accent-primary);
            transform: translateY(-2px);
        }
        .stat-number {
            font-size: 2em;
            font-weight: 700;
            color: #8b5cf6;
        }
        .stat-label {
            color: var(--text-secondary);
            margin-top: 8px;
            font-size: 0.9em;
        }
        
        /* Archive badge */
        .archived-badge {
            background: var(--text-muted);
            color: var(--bg-card);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.75em;
            font-weight: 600;
            margin-left: 8px;
        }
        
        /* Improved textarea */
        textarea {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            background: var(--bg-input);
            color: var(--text-primary);
            font-size: 1em;
            font-family: inherit;
            transition: all 0.2s ease;
            resize: vertical;
        }
        textarea:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
        }
        
        /* Info Tooltips */
        .info-icon { 
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: var(--border-color);
            color: var(--text-muted);
            font-size: 0.65em;
            font-weight: 700;
            cursor: help;
            position: relative;
            margin-left: 6px;
            font-style: normal;
            transition: all 0.2s;
        }
        .info-icon:hover { 
            background: var(--accent-primary);
            color: #fff;
        }
        .info-icon::after { 
            content: attr(data-tip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: var(--bg-secondary);
            border: 1px solid var(--border-light);
            color: var(--text-primary);
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            font-size: 13px;
            font-weight: 400;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.2s;
            z-index: 100;
            pointer-events: none;
            margin-bottom: 8px;
            max-width: 400px;
            min-width: 280px;
            white-space: normal;
            text-align: left;
            line-height: 1.6;
            box-shadow: var(--shadow-md);
        }
        .info-icon:hover::after { opacity: 1; visibility: visible; }
        .info-icon.tip-left::after { left: auto; right: 0; transform: none; }
        .info-icon.tip-right::after { left: 0; transform: none; }
        
        @media (max-width: 768px) {
            .container { padding: 16px; }
            h1 { font-size: 1.8em; }
            .tabs { flex-direction: column; }
            .hide-mobile { display: none; }
            .form-group { min-width: 48%; }
            table { font-size: 0.85em; }
            th, td { padding: 12px 8px; }
            .card { padding: 20px; }
            .checkbox-row { gap: 16px; }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>✈️ <span class="delta">Delta</span> Flight Tracker</h1>
    
    <!-- Update Available Banner (hidden by default) -->
    <div id="updateBanner" style="display: none; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 10px 16px; border-radius: 8px; margin-bottom: 16px; display: none; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.2em;">🎉</span>
            <span><strong>Update Available!</strong> Version <span id="latestVersion"></span> is available.</span>
        </div>
        <a id="updateLink" href="#" target="_blank" style="background: white; color: #059669; padding: 6px 14px; border-radius: 6px; text-decoration: none; font-weight: 500; font-size: 0.9em;">Download Update</a>
    </div>
    
    <!-- Connection/System Alert Banner -->
    {% if connection_failures > 0 %}
    <div id="alertBanner" style="background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%); color: white; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.3em;">⚠️</span>
            <div>
                <strong>Connection Issues Detected</strong>
                <div style="font-size: 0.85em; opacity: 0.9;">{{ connection_failures }} price check(s) failed in the last 24 hours due to connection problems. Make sure you're connected to the internet.</div>
            </div>
        </div>
        <button onclick="dismissAlerts()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 0.85em;">Dismiss</button>
    </div>
    {% endif %}
    
    <!-- Tabs -->
    <div class="tabs">
        <div class="tab active" onclick="showTab('flights')">✈️ Flights</div>
        <div class="tab" onclick="showTab('history')">📈 History</div>
        <div class="tab" onclick="showTab('settings')">⚙️ Settings</div>
    </div>
    
    <!-- FLIGHTS TAB -->
    <div id="tab-flights" class="tab-content active">
        <!-- Flight Limit Warning -->
        {% if stats.total_flights >= 6 %}
        <div style="margin-bottom: 16px; padding: 12px 16px; background: {{ '#fff3cd' if stats.total_flights >= 8 else '#d1ecf1' }}; border-radius: var(--radius-md); border: 1px solid {{ '#ffc107' if stats.total_flights >= 8 else '#bee5eb' }};">
            {% if stats.total_flights >= 8 %}
            <strong style="color: #856404;">⚠️ Flight limit reached ({{ stats.total_flights }}/8)</strong>
            <span style="color: #856404;">— Archive or remove flights before adding new ones. This limit helps avoid bot detection by Delta.</span>
            {% else %}
            <strong style="color: #0c5460;">ℹ️ {{ stats.total_flights }}/8 flights</strong>
            <span style="color: #0c5460;">— You can add {{ 8 - stats.total_flights }} more flight{{ 's' if (8 - stats.total_flights) != 1 else '' }}.</span>
            {% endif %}
        </div>
        {% endif %}
        
        <!-- Add/Edit Form -->
        <div class="card">
            <h2>{{ "✏️ Edit Flight" if edit_flight else "➕ Add Flight to Track" }}<i class="info-icon" data-tip="Track flights to see price changes over time. Compare cash prices vs SkyMiles to find the best deal.">i</i></h2>
            
            {% if edit_flight and (edit_flight.price or edit_flight.lowest or edit_flight.highest) %}
            <!-- Flight Summary (shown when editing) -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; margin-bottom: 20px; padding: 16px; background: var(--bg-secondary); border-radius: var(--radius-md);">
                <div style="text-align: center;">
                    <div style="font-size: 0.75em; color: var(--text-muted); margin-bottom: 4px;">Current Price</div>
                    <div style="font-size: 1.2em; font-weight: 600;">
                        {% if edit_flight.price %}
                            {% if edit_flight.miles %}{{ '{:,.0f}'.format(edit_flight.price) }} mi{% else %}${{ '{:,.0f}'.format(edit_flight.price) }}{% endif %}
                        {% else %}—{% endif %}
                    </div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 0.75em; color: var(--text-muted); margin-bottom: 4px;">Lowest Found</div>
                    <div style="font-size: 1.2em; font-weight: 600; color: var(--accent-green);">
                        {% if edit_flight.lowest %}
                            {% if edit_flight.miles %}{{ '{:,.0f}'.format(edit_flight.lowest) }} mi{% else %}${{ '{:,.0f}'.format(edit_flight.lowest) }}{% endif %}
                        {% else %}—{% endif %}
                    </div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 0.75em; color: var(--text-muted); margin-bottom: 4px;">Highest Seen</div>
                    <div style="font-size: 1.2em; font-weight: 600; color: var(--accent-red);">
                        {% if edit_flight.highest %}
                            {% if edit_flight.miles %}{{ '{:,.0f}'.format(edit_flight.highest) }} mi{% else %}${{ '{:,.0f}'.format(edit_flight.highest) }}{% endif %}
                        {% else %}—{% endif %}
                    </div>
                </div>
                {% if edit_flight.highest and edit_flight.lowest %}
                <div style="text-align: center;">
                    <div style="font-size: 0.75em; color: var(--text-muted); margin-bottom: 4px;">Price Range</div>
                    <div style="font-size: 1.2em; font-weight: 600;">
                        {% if edit_flight.miles %}{{ '{:,.0f}'.format(edit_flight.highest - edit_flight.lowest) }} mi{% else %}${{ '{:,.0f}'.format(edit_flight.highest - edit_flight.lowest) }}{% endif %}
                    </div>
                </div>
                {% endif %}
                {% if edit_flight.claimed_savings %}
                <div style="text-align: center; border-left: 2px solid var(--accent-green); padding-left: 12px;">
                    <div style="font-size: 0.75em; color: var(--accent-green); margin-bottom: 4px;">✅ Claimed</div>
                    <div style="font-size: 1.2em; font-weight: 600; color: var(--accent-green);">
                        {% if edit_flight.miles %}{{ '{:,.0f}'.format(edit_flight.claimed_savings) }} mi{% else %}${{ '{:,.0f}'.format(edit_flight.claimed_savings) }}{% endif %}
                    </div>
                </div>
                {% endif %}
            </div>
            {% endif %}
            
            <form method="POST" action="{{ '/update/' + edit_flight.id|string if edit_flight else '/add' }}">
                <div class="form-row">
                    <div class="form-group" style="max-width:100px"><label>From<i class="info-icon" data-tip="Your departure airport code (like MSP for Minneapolis, JFK for New York, LAX for Los Angeles)">i</i></label><input name="origin" placeholder="MSP" maxlength="3" required value="{{ edit_flight.origin if edit_flight else '' }}" style="text-transform:uppercase"></div>
                    <div class="form-group" style="max-width:100px"><label>To<i class="info-icon" data-tip="Your destination airport code (like SJU for San Juan, MIA for Miami, ATL for Atlanta)">i</i></label><input name="dest" placeholder="SJU" maxlength="3" required value="{{ edit_flight.dest if edit_flight else '' }}" style="text-transform:uppercase"></div>
                    <div class="form-group"><label>Depart<i class="info-icon" data-tip="The date you want to fly out">i</i></label><input type="date" name="dep_date" required value="{{ edit_flight.dep_date if edit_flight else '' }}"></div>
                    <div class="form-group"><label>Return<i class="info-icon" data-tip="Your return date, or leave blank for one-way trips">i</i></label><input type="date" name="ret_date" value="{{ edit_flight.ret_date if edit_flight else '' }}"></div>
                    <div class="form-group"><label>Time<i class="info-icon" data-tip="Optional: Track a specific departure time. Leave blank to find the lowest price at any time.">i</i></label>
                        <div style="display:flex;gap:6px;">
                            <select name="dep_hour" style="width:70px;">
                                <option value="">--</option>
                                {% for h in range(1,13) %}<option value="{{ h }}" {{ 'selected' if edit_flight and edit_flight.dep_time and edit_flight.dep_time.split(':')[0]|replace('12','12')|int == h else '' }}>{{ h }}</option>{% endfor %}
                            </select>
                            <select name="dep_min" style="width:80px;">
                                <option value="">--</option>
                                {% for m in range(60) %}<option value="{{ '%02d'|format(m) }}" {{ 'selected' if edit_flight and edit_flight.dep_time and edit_flight.dep_time.split(':')[1][:2] == '%02d'|format(m) else '' }}>:{{ '%02d'|format(m) }}</option>{% endfor %}
                            </select>
                            <select name="dep_ampm" style="width:75px;">
                                <option value="">--</option>
                                <option value="am" {{ 'selected' if edit_flight and edit_flight.dep_time and 'am' in edit_flight.dep_time else '' }}>AM</option>
                                <option value="pm" {{ 'selected' if edit_flight and edit_flight.dep_time and 'pm' in edit_flight.dep_time else '' }}>PM</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="checkbox-row">
                    <label><input type="checkbox" name="miles" {{ 'checked' if edit_flight and edit_flight.miles else '' }}> Shop with Miles<i class="info-icon" data-tip="Search using SkyMiles points instead of dollars. Great for comparing if you should use points or pay cash.">i</i></label>
                    <label><input type="checkbox" name="exclude_basic" {{ 'checked' if edit_flight and edit_flight.exclude_basic else '' }}> Exclude Basic Economy<i class="info-icon" data-tip="Skip Basic Economy fares (no seat selection, board last). Only works for cash searches, not award flights.">i</i></label>
                    <label><input type="checkbox" name="scheduled" {{ 'checked' if (not edit_flight) or edit_flight.scheduled else '' }}> Include in Daily Checks<i class="info-icon" data-tip="When enabled in Settings, this flight will be automatically checked once per day. Uncheck to exclude this flight from automatic checks.">i</i></label>
                    {% if edit_flight %}<label><input type="checkbox" name="active" {{ 'checked' if edit_flight.active else '' }}> Active<i class="info-icon" data-tip="Uncheck to pause tracking without deleting. Inactive flights stay in your list but won't be checked.">i</i></label>{% endif %}
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Notes (optional)
                            <i class="info-icon" data-tip="Add personal notes about this flight (preferences, seat requests, connections, etc.)">i</i>
                        </label>
                        <textarea name="notes" placeholder="e.g., Window seat preferred, connecting through ATL..." 
                                  rows="2">{{ edit_flight.notes if edit_flight else '' }}</textarea>
                    </div>
                </div>
                
                <!-- Price Paid Section -->
                <div style="margin-top: 16px; padding: 16px; background: var(--bg-secondary); border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                    <div style="font-weight: 500; margin-bottom: 12px; color: var(--text-primary);">
                        💰 Price Tracking & Savings
                        <i class="info-icon" data-tip="Enter what you paid to track refund eligibility. When price drops below your paid amount, you can log your savings.">i</i>
                    </div>
                    <div class="form-row" style="margin-bottom: 12px;">
                        <div class="form-group" style="max-width: 150px;">
                            <label>Cash Price Paid<i class="info-icon" data-tip="The dollar amount you paid for this flight">i</i></label>
                            <input type="number" name="paid_price" placeholder="350" min="0" step="0.01" value="{{ edit_flight.paid_price if edit_flight and edit_flight.paid_price else '' }}">
                        </div>
                        <div class="form-group" style="max-width: 150px;">
                            <label>Miles Spent<i class="info-icon" data-tip="The number of SkyMiles you redeemed">i</i></label>
                            <input type="number" name="paid_miles" placeholder="25000" min="0" value="{{ edit_flight.paid_miles if edit_flight and edit_flight.paid_miles else '' }}">
                        </div>
                        <div class="form-group" style="max-width: 150px;">
                            <label>Claimed Savings<i class="info-icon" data-tip="Amount you saved by rebooking at a lower price. Enter manually or use the 'Claim Savings' button when price drops.">i</i></label>
                            <input type="number" name="claimed_savings" placeholder="0" min="0" step="0.01" value="{{ edit_flight.claimed_savings if edit_flight and edit_flight.claimed_savings else '' }}">
                        </div>
                    </div>
                    <label style="font-size: 0.9em;">
                        <input type="checkbox" name="alert_below_paid" {{ 'checked' if edit_flight and edit_flight.alert_below_paid else '' }}>
                        Only alert me if price drops <strong>below what I paid</strong>
                        <i class="info-icon" data-tip="When checked, you'll only get email alerts when the price falls below your paid amount.">i</i>
                    </label>
                    {% if edit_flight %}
                    <div style="margin-top: 12px; padding: 10px; background: var(--bg-primary); border-radius: var(--radius-sm); font-size: 0.85em; color: var(--text-muted);">
                        💡 <strong>How savings work:</strong> When the current price drops below what you paid, a green "Claim Savings" button appears in the flights table. Click it when you've rebooked to log your savings, or enter the amount manually above.
                    </div>
                    {% endif %}
                </div>
                
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary">{{ "💾 Update" if edit_flight else "➕ Add Flight" }}</button>
                    {% if edit_flight %}<a href="/" class="btn btn-secondary">Cancel</a>{% endif %}
                </div>
            </form>
        </div>
        
        <!-- Statistics Dashboard -->
        <div class="card">
            <h2>📊 Your Tracking Stats</h2>
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px; margin-top:20px;">
                <div class="stat-card" style="border-color: var(--accent-green); cursor: help;" title="How to claim savings: 1) Edit a flight and enter what you paid. 2) When price drops below that, a 'Claim Savings' button appears. 3) Click it after you rebook at the lower price.">
                    <div class="stat-number" style="color: var(--accent-green);">${{ '{:,.0f}'.format(stats.claimed_savings) }}</div>
                    <div class="stat-label">Claimed Savings<i class="info-icon" data-tip="Money you've actually saved by rebooking. To use: Edit a flight → Enter 'Price You Paid' → When price drops below that, click 'Claim Savings' button.">i</i></div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${{ '{:,.0f}'.format(stats.total_savings) }}</div>
                    <div class="stat-label">Potential Savings<i class="info-icon" data-tip="Total price drops found across all flights (highest - lowest)">i</i></div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ stats.total_flights }}</div>
                    <div class="stat-label">Active Flights</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">{{ stats.total_checks }}</div>
                    <div class="stat-label">Price Checks</div>
                </div>
            </div>
            
            {% if stats.best_deal %}
            <div style="margin-top:24px; padding:16px; background:var(--bg-secondary); border-radius:var(--radius-md); border:2px solid var(--accent-green);">
                <div style="font-weight:600; color:var(--accent-green); margin-bottom:8px;">🏆 Best Deal Found</div>
                <div style="font-size:1.1em;">{{ stats.best_deal.route }}: Saved ${{ '{:,.0f}'.format(stats.best_deal.saved) }}</div>
                <div style="font-size:0.85em; color:var(--text-muted); margin-top:4px;">
                    Was ${{ '{:,.0f}'.format(stats.best_deal.was) }} → Now ${{ '{:,.0f}'.format(stats.best_deal.now) }}
                </div>
            </div>
            {% endif %}
        </div>
        
        <!-- Flights Table -->
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
                <h2 style="margin:0">📊 Tracked Flights<i class="info-icon" data-tip="All your flights being monitored. Prices update when you run checks.">i</i></h2>
                <div style="display:flex; gap:10px;">
                    <button class="btn btn-secondary" onclick="exportData()" title="Export all flights as JSON">📥 Export</button>
                    <button class="btn btn-secondary" onclick="document.getElementById('importFile').click()" title="Import flights from JSON">📤 Import</button>
                    <input type="file" id="importFile" accept=".json" style="display:none" onchange="importData(event)">
                    <button class="btn btn-primary" onclick="autoCheckAll()" id="checkAllBtn" title="Check all flights marked for daily checks">🤖 Check All Now<i class="info-icon" data-tip="Manually run the daily price check now. Checks each flight ~20 minutes apart to avoid bot detection.">i</i></button>
                </div>
            </div>
            {% if flights %}
            
            {% if active_flights %}
            <table id="flightsTable">
                <thead>
                    <tr>
                        <th style="width: 40px;" title="Drag to reorder or use arrows">⋮⋮</th>
                        <th class="sortable" data-sort="route" onclick="sortTable('route')">Route<i class="info-icon" data-tip="Your flight route with airport codes. Click to sort.">i</i></th>
                        <th class="sortable" data-sort="date" onclick="sortTable('date')">Dates<i class="info-icon" data-tip="Departure date. Click to sort.">i</i></th>
                        <th class="hide-mobile">Time<i class="info-icon" data-tip="Specific departure time you're tracking">i</i></th>
                        <th>Type<i class="info-icon" data-tip="Cash means dollars, Miles means SkyMiles">i</i></th>
                        <th class="sortable" data-sort="price" onclick="sortTable('price')">Price<i class="info-icon" data-tip="Most recent price. Click to sort.">i</i></th>
                        <th class="sortable" data-sort="lowest" onclick="sortTable('lowest')">Lowest<i class="info-icon" data-tip="Best price found. Click to sort.">i</i></th>
                        <th class="hide-mobile">Daily<i class="info-icon" data-tip="Included in daily automatic price check">i</i></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="flightsTableBody">
                {% for f in active_flights %}
                    <tr data-id="{{ f.id }}" data-route="{{ f.origin }}{{ f.dest }}" data-date="{{ f.dep_date }}" data-price="{{ f.price or 0 }}" data-lowest="{{ f.lowest or 0 }}" style="{{ 'opacity:0.5' if not f.active else '' }}">
                        <td>
                            <div class="move-btns">
                                <button class="move-btn" onclick="moveRow({{ f.id }}, 'up')" title="Move up">▲</button>
                                <button class="move-btn" onclick="moveRow({{ f.id }}, 'down')" title="Move down">▼</button>
                            </div>
                        </td>
                        <td class="route">{{ f.origin }}<span class="arrow">→</span>{{ f.dest }}</td>
                        <td>
                            {{ f.dep_date[5:] if f.dep_date else '—' }}
                            {% set days = days_until(f.dep_date) %}
                            {% if days is not none %}
                                {% if days < 0 %}
                                    <span style="font-size:0.7em; color:var(--text-muted);">(past)</span>
                                {% elif days == 0 %}
                                    <span style="font-size:0.7em; color:var(--accent-red); font-weight:600;">TODAY!</span>
                                {% elif days <= 3 %}
                                    <span style="font-size:0.7em; color:var(--accent-red);">({{ days }}d)</span>
                                {% elif days <= 7 %}
                                    <span style="font-size:0.7em; color:var(--warning);">({{ days }}d)</span>
                                {% elif days <= 30 %}
                                    <span style="font-size:0.7em; color:var(--text-muted);">({{ days }}d)</span>
                                {% endif %}
                            {% endif %}
                            <br><span class="timestamp">{{ f.ret_date[5:] if f.ret_date else '(one-way)' }}</span>
                        </td>
                        <td class="hide-mobile">{{ f.dep_time or '—' }}</td>
                        <td><span class="badge {{ 'badge-miles' if f.miles else 'badge-cash' }}">{{ 'Miles' if f.miles else 'Cash' }}</span></td>
                        <td>
                            {% if f.price %}
                            <span class="price {{ 'price-miles' if f.miles else 'price-cash' }}">
                                {% if f.miles %}{{ '{:,.0f}'.format(f.price) }} mi{% else %}${{ '{:,.0f}'.format(f.price) }}{% endif %}
                            </span>
                            
                            {% if f.highest and f.price < f.highest %}
                                {% set percent_drop = ((f.highest - f.price) / f.highest * 100) %}
                                <span class="price-change price-down">
                                    ↓ {{ '{:.0f}'.format(percent_drop) }}%
                                </span>
                                {% if percent_drop >= 20 %}
                                    <span class="price-badge badge-hot">🔥 Hot</span>
                                {% elif percent_drop >= 10 %}
                                    <span class="price-badge badge-good">💰 Good</span>
                                {% endif %}
                            {% elif f.lowest and f.price > f.lowest %}
                                {% set percent_rise = ((f.price - f.lowest) / f.lowest * 100) %}
                                <span class="price-change price-up">
                                    ↑ {{ '{:.0f}'.format(percent_rise) }}%
                                </span>
                            {% endif %}
                            
                            <!-- Show paid price below current price -->
                            {% if f.paid_price or f.paid_miles %}
                                {% set paid_val = (f.paid_miles if f.miles else f.paid_price) or 0 %}
                                {% set paid_display = ('{:,.0f} mi'.format(f.paid_miles) if f.miles and f.paid_miles else '${:,.0f}'.format(f.paid_price) if f.paid_price else '') %}
                                {% if paid_display %}
                                <div style="font-size: 0.75em; color: var(--text-muted); margin-top: 2px;">
                                    Paid: {{ paid_display }}
                                    {% if paid_val and f.price < paid_val %}
                                        <span style="color: var(--accent-green);">✓ {{ '{:,.0f}'.format(paid_val - f.price) }} below!</span>
                                    {% endif %}
                                </div>
                                {% endif %}
                            {% endif %}
                            
                            <!-- Show claimed savings or claim button -->
                            {% if f.claimed_savings %}
                                <div style="font-size: 0.7em; color: var(--accent-green); margin-top: 2px;">
                                    ✅ Saved {% if f.miles %}{{ '{:,.0f}'.format(f.claimed_savings) }} mi{% else %}${{ '{:,.0f}'.format(f.claimed_savings) }}{% endif %}
                                </div>
                            {% elif f.paid_price or f.paid_miles %}
                                {% set paid_val = (f.paid_miles if f.miles else f.paid_price) or 0 %}
                                {% if paid_val and f.price and f.price < paid_val %}
                                <button onclick="claimSavings({{ f.id }}, {{ paid_val - f.price }})" 
                                        class="btn btn-small" 
                                        style="font-size: 0.65em; padding: 2px 6px; margin-top: 4px; background: var(--accent-green); color: white;"
                                        title="Click if you rebooked at this lower price">
                                    💵 Claim Savings
                                </button>
                                {% endif %}
                            {% endif %}
                            
                            {% if f.notes %}
                                <i class="info-icon" data-tip="{{ f.notes }}" style="margin-left:6px; cursor:help;">📝</i>
                            {% endif %}
                            {% else %}—{% endif %}
                        </td>
                        <td>
                            {% if f.lowest %}
                            <span class="price-lowest">{% if f.miles %}{{ '{:,.0f}'.format(f.lowest) }} mi{% else %}${{ '{:,.0f}'.format(f.lowest) }}{% endif %}</span>
                            {% else %}—{% endif %}
                        </td>
                        <td class="hide-mobile">
                            <button class="toggle-btn {{ 'toggle-on' if f.scheduled else 'toggle-off' }}" 
                                    onclick="toggleSchedule({{ f.id }}, {{ 'false' if f.scheduled else 'true' }})"
                                    title="{{ 'Included in daily checks - click to exclude' if f.scheduled else 'Not in daily checks - click to include' }}">
                                {{ '✓ Daily' if f.scheduled else '＋ Add' }}
                            </button>
                        </td>
                        <td>
                            <div class="actions">
                                <button class="btn btn-secondary btn-small" onclick="autoCheckOne({{ f.id }})" title="Auto-check this flight now">🤖</button>
                                <a href="{{ delta_url(f) }}" target="_blank" class="btn btn-secondary btn-small" title="Open Delta.com search">🔗</a>
                                <a href="/edit/{{ f.id }}" class="btn btn-secondary btn-small" title="Edit flight details">✏️</a>
                                <button onclick="duplicateFlight({{ f.id }})" class="btn btn-secondary btn-small" title="Duplicate this flight (same route, new dates)">📋</button>
                                <button onclick="archiveFlight({{ f.id }})" class="btn btn-secondary btn-small" title="Archive this flight">📦</button>
                                <button onclick="deleteFlight({{ f.id }}, '{{ f.origin }} → {{ f.dest }}')" class="btn btn-secondary btn-small" title="Delete this flight" style="color: var(--accent-red);">🗑️</button>
                                {% if f.last_checked %}
                                <span class="last-checked-inline" title="Last checked at this time">{{ format_time(f.last_checked, settings) }}</span>
                                {% endif %}
                            </div>
                        </td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
            {% else %}
            <div class="empty">
                <p>No active flights tracked yet.</p>
                <p style="margin-top:8px;font-size:0.9em">Add a flight above to get started!</p>
            </div>
            {% endif %}
            
            <!-- Archived Flights Section -->
            {% if archived_flights %}
            <div style="margin-top: 32px; border-top: 1px solid var(--border-color); padding-top: 24px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                    <h3 style="margin: 0; color: var(--text-muted); font-size: 1em;">
                        📦 Archived Flights ({{ archived_flights | length }})
                        <i class="info-icon" data-tip="Flights you've archived. They won't be checked but you can restore them anytime.">i</i>
                    </h3>
                    <button onclick="document.getElementById('archivedTable').style.display = document.getElementById('archivedTable').style.display === 'none' ? 'table' : 'none'" 
                            class="btn btn-secondary btn-small">
                        Show/Hide
                    </button>
                </div>
                <table id="archivedTable" style="display: none; opacity: 0.7;">
                    <thead>
                        <tr>
                            <th>Route</th>
                            <th>Dates</th>
                            <th>Final Price</th>
                            <th>Savings</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    {% for f in archived_flights %}
                        <tr>
                            <td class="route">{{ f.origin }}<span class="arrow">→</span>{{ f.dest }}</td>
                            <td>{{ f.dep_date }}</td>
                            <td>
                                {% if f.price %}
                                    {% if f.miles %}{{ '{:,.0f}'.format(f.price) }} mi{% else %}${{ '{:,.0f}'.format(f.price) }}{% endif %}
                                {% else %}—{% endif %}
                            </td>
                            <td>
                                {% if f.claimed_savings %}
                                    <span style="color: var(--accent-green);">✅ ${{ '{:,.0f}'.format(f.claimed_savings) }}</span>
                                {% elif f.highest and f.lowest %}
                                    ${{ '{:,.0f}'.format(f.highest - f.lowest) }}
                                {% else %}—{% endif %}
                            </td>
                            <td>
                                <button onclick="restoreFlight({{ f.id }})" class="btn btn-primary btn-small" title="Restore this flight to active tracking">
                                    ↩️ Restore
                                </button>
                                <button onclick="deleteFlight({{ f.id }}, '{{ f.origin }} → {{ f.dest }}')" 
                                        class="btn btn-secondary btn-small" title="Permanently delete" style="color: var(--accent-red);">🗑️</button>
                            </td>
                        </tr>
                    {% endfor %}
                    </tbody>
                </table>
            </div>
            {% endif %}
            {% endif %}
        </div>
    </div>
    
    <!-- HISTORY TAB -->
    <div id="tab-history" class="tab-content">
        <div class="card">
            <h2>📈 Price Check History<i class="info-icon" data-tip="Complete log of all price checks. Click 'View Screenshot' to see exactly what Delta showed.">i</i></h2>
            {% if history %}
            <div>
            {% for h in history %}
                <div class="history-item {{ 'has-screenshot-item' if h.screenshot else '' }}">
                    <div class="history-main" onclick="toggleScreenshot({{ h.id }})">
                        <div>
                            <strong>{{ h.origin }}<span class="arrow">→</span>{{ h.dest }}</strong>
                            <span class="timestamp" style="margin-left:8px">{{ h.dep_date[5:] if h.dep_date else '' }}</span>
                            {% if h.price %}
                            <span class="price {{ 'price-miles' if h.miles else 'price-cash' }}" style="margin-left:8px">
                                {% if h.miles %}{{ '{:,.0f}'.format(h.price) }} mi{% else %}${{ '{:,.0f}'.format(h.price) }}{% endif %}
                            </span>
                            {% elif h.error %}
                            <span style="color:#f85149;margin-left:8px">{{ h.error[:40] }}</span>
                            {% endif %}
                            <span class="badge {{ 'badge-auto' if h.check_type == 'auto' else 'badge-manual' }}" style="margin-left:6px">{{ h.check_type }}</span>
                            {% if h.screenshot %}
                            <span class="screenshot-btn" title="Click to view the actual Delta.com screenshot">📷 View Screenshot</span>
                            {% endif %}
                        </div>
                        <span class="timestamp">{{ h.checked_at[5:10] if h.checked_at else '' }} {{ format_time(h.checked_at, settings) if h.checked_at else '' }}</span>
                    </div>
                    {% if h.screenshot %}
                    <div class="history-screenshot" id="screenshot-{{ h.id }}">
                        <img src="/screenshot/{{ h.id }}" alt="Price screenshot from Delta.com">
                    </div>
                    {% endif %}
                </div>
            {% endfor %}
            </div>
            {% else %}
            <div class="empty" style="padding:20px">No price history yet.</div>
            {% endif %}
        </div>
    </div>
    
    <!-- SETTINGS TAB -->
    <div id="tab-settings" class="tab-content">
        <div class="card">
            <h2>📧 Email Notifications<i class="info-icon" data-tip="Get email alerts when prices drop. Requires Gmail with an App Password.">i</i></h2>
            
            <!-- App Password Notice -->
            <div style="background: linear-gradient(135deg, #1e3a5f 0%, #0d2137 100%); border: 1px solid #3b82f6; border-radius: 8px; padding: 14px 16px; margin-bottom: 20px;">
                <div style="display: flex; align-items: flex-start; gap: 10px;">
                    <span style="font-size: 1.2em;">🔐</span>
                    <div style="font-size: 0.9em;">
                        <strong style="color: #60a5fa;">Gmail App Password Required</strong>
                        <div style="color: #94a3b8; margin-top: 4px; line-height: 1.5;">
                            For security, we only accept <strong style="color: #e2e8f0;">Google App Passwords</strong> (not your regular Gmail password).
                            This is a special 16-character code you create in Google.
                        </div>
                        <a href="https://myaccount.google.com/apppasswords" target="_blank" style="color: #60a5fa; text-decoration: none; display: inline-block; margin-top: 8px; font-weight: 500;">
                            → Create App Password at Google Account
                        </a>
                    </div>
                </div>
            </div>
            
            <form method="POST" action="/save-settings">
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Send alerts to<i class="info-icon" data-tip="Where you want to receive price drop alerts (can be any email)">i</i></label>
                        <input type="email" name="email_to" placeholder="your@email.com" value="{{ settings.email_to }}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Gmail address (sender)<i class="info-icon" data-tip="Your Gmail account that will send the alerts (must be Gmail)">i</i></label>
                        <input type="email" name="email_from" placeholder="yourgmail@gmail.com" value="{{ settings.email_from }}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>App Password (16 characters, no spaces)<i class="info-icon" data-tip="The 16-character App Password from Google. Format: xxxx xxxx xxxx xxxx (spaces optional)">i</i></label>
                        <input type="password" name="email_password" id="appPasswordInput" placeholder="xxxx xxxx xxxx xxxx" value="{{ settings.email_password }}" pattern="[a-zA-Z ]{16,19}" title="Enter your 16-character Google App Password">
                        <span class="help-text">Looks like: <code style="background:#1e293b; padding:2px 6px; border-radius:4px;">abcd efgh ijkl mnop</code></span>
                    </div>
                </div>
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary" title="Save email configuration">💾 Save Email Settings</button>
                    <button type="button" class="btn btn-secondary" onclick="testEmail()" title="Send a test email to verify settings">📤 Test Email</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>🔐 Delta Login (Experimental)<i class="info-icon" data-tip="Under development. Will track member-exclusive pricing in a future update.">i</i></h2>
            <p class="help-text" style="margin-bottom:16px; color:#888">
                Login to see member-specific prices (like credit card discounts). 
                The tracker will log in via delta.com homepage before searching.
            </p>
            <form method="POST" action="/save-settings">
                <input type="hidden" name="settings_type" value="delta_login">
                <div class="checkbox-row" style="margin-bottom:16px">
                    <label>
                        <input type="checkbox" name="delta_login_enabled" {{ 'checked' if settings.delta_login_enabled else '' }}>
                        Enable Delta login for price checks<i class="info-icon" data-tip="Log in to Delta before each search to see member pricing and credit card discounts">i</i>
                    </label>
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Delta Username/Email<i class="info-icon" data-tip="Your SkyMiles number or Delta email address">i</i></label>
                        <input type="text" name="delta_username" placeholder="your@email.com or SkyMiles#" value="{{ settings.delta_username }}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Delta Password<i class="info-icon" data-tip="Your Delta.com password (stored encoded, not as plain text)">i</i></label>
                        <input type="password" name="delta_password" id="delta_password" placeholder="{{ '••••••••' if settings.delta_password_encoded else 'Enter password' }}">
                        <span class="help-text">{{ '✓ Password saved' if settings.delta_password_encoded else 'Not yet saved' }}</span>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group wide">
                        <label>Last Name (if verification required)<i class="info-icon" data-tip="Delta sometimes asks for last name when logging in from new devices">i</i></label>
                        <input type="text" name="delta_last_name" placeholder="Smith" value="{{ settings.delta_last_name }}">
                        <span class="help-text">Delta sometimes asks for last name on new devices</span>
                    </div>
                </div>
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary" title="Save Delta credentials">💾 Save Delta Login</button>
                    <button type="button" class="btn btn-secondary" onclick="testDeltaLogin()" title="Test login in visible browser">🔑 Test Login</button>
                </div>
                <p class="help-text" style="margin-top:12px">
                    Test opens a visible browser so you can watch the login attempt and see what happens.
                </p>
            </form>
        </div>
        
        <div class="card">
            <h2>⏰ Daily Price Check<i class="info-icon" data-tip="Automatically check prices once per day. Best time is early morning when airline prices update overnight.">i</i></h2>
            <form method="POST" action="/save-settings">
                <input type="hidden" name="settings_type" value="schedule">
                <div class="checkbox-row" style="margin-bottom:16px">
                    <label>
                        <input type="checkbox" name="schedule_enabled" {{ 'checked' if settings.schedule_enabled else '' }}>
                        Enable daily price checks
                        <i class="info-icon" data-tip="When ON, the app will automatically check all your flights once per day at the time below. Your computer must be on and the app running in the system tray.">i</i>
                    </label>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Check Time<i class="info-icon" data-tip="Recommended: 3:00-5:00 AM. Delta typically updates prices overnight, so early morning catches fresh prices before they change.">i</i></label>
                        <input type="time" name="schedule_time" value="{{ settings.schedule_time if settings.schedule_time else '03:00' }}">
                        <span class="help-text">💡 3-5 AM recommended (prices update overnight)</span>
                    </div>
                </div>
                <p class="help-text" style="margin:12px 0; padding:12px; background:var(--bg-secondary); border-radius:var(--radius-sm);">
                    <strong>How it works:</strong> Each flight is checked ~{{ settings.stagger_minutes|default(20) }} minutes apart to avoid bot detection.<br>
                    With {{ stats.total_flights }} active flight{{ 's' if stats.total_flights != 1 else '' }}, 
                    checking will take about {{ (stats.total_flights * (settings.stagger_minutes|default(20))) }} minutes to complete.
                </p>
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary">💾 Save Schedule</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>🕐 Display Preferences<i class="info-icon" data-tip="Customize how times are displayed throughout the app">i</i></h2>
            <form method="POST" action="/save-settings">
                <input type="hidden" name="settings_type" value="display">
                <div class="checkbox-row" style="margin-bottom:16px">
                    <label>
                        <input type="checkbox" name="time_format_24h" {{ 'checked' if settings.time_format_24h else '' }}>
                        Use 24-hour time format<i class="info-icon" data-tip="Show times like 18:00 instead of 6:00 PM">i</i>
                    </label>
                </div>
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary">💾 Save Preferences</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>🎯 Price Alert Thresholds<i class="info-icon" data-tip="Set minimum requirements for price drop alerts">i</i></h2>
            <p class="help-text" style="margin-bottom:16px;">
                Only receive emails when prices drop by at least this much. Set to 0 to get alerts for any price drop.
            </p>
            <form method="POST" action="/save-settings">
                <input type="hidden" name="settings_type" value="thresholds">
                <div class="form-row">
                    <div class="form-group">
                        <label>Minimum dollar drop
                            <i class="info-icon" data-tip="Only alert if price drops by at least this many dollars (0 = any drop)">i</i>
                        </label>
                        <input type="number" name="price_alert_min_dollars" 
                               value="{{ settings.price_alert_min_dollars }}" min="0" step="1">
                        <span class="help-text">e.g., 50 = only alert if saves $50+</span>
                    </div>
                    <div class="form-group">
                        <label>Minimum percent drop
                            <i class="info-icon" data-tip="Only alert if price drops by at least this percentage (0 = any drop)">i</i>
                        </label>
                        <input type="number" name="price_alert_min_percent" 
                               value="{{ settings.price_alert_min_percent }}" min="0" max="100" step="1">
                        <span class="help-text">e.g., 10 = only alert if drops 10%+</span>
                    </div>
                </div>
                <p class="help-text" style="margin:12px 0; padding:12px; background:var(--bg-secondary); border-radius:var(--radius-sm);">
                    ℹ️ If both are set, the price drop must meet at least ONE threshold to trigger an alert.
                    If both are 0, you'll get alerts for any price drop.
                </p>
                <div class="btn-row">
                    <button type="submit" class="btn btn-primary">💾 Save Thresholds</button>
                </div>
            </form>
        </div>
        
        <div class="card">
            <h2>ℹ️ Tips</h2>
            <ul style="color:#8b949e; line-height:1.8; padding-left:20px;">
                <li><strong>Background checks:</strong> Firefox runs invisibly - use your PC normally!</li>
                <li><strong>Bot detection:</strong> Spacing checks 10-15 min apart helps avoid blocks</li>
                <li><strong>Screenshots:</strong> Auto-checks capture proof of each price found - click to view</li>
                <li><strong>Delta link:</strong> Click 🔗 to open the actual Delta search for that flight</li>
            </ul>
        </div>
    </div>
    
    <!-- Donation Section - Compact with colored icons -->
    <div class="card" style="margin-top: 32px; padding: 16px 20px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.2em;">☕</span>
                <span style="font-weight: 500; color: var(--text-primary);">Saved money on a flight? Buy me a coffee!</span>
            </div>
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <a href="https://cash.app/$SteveVogt" target="_blank" style="text-decoration: none; display: flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #00D632 0%, #00B828 100%); color: white; padding: 8px 14px; border-radius: 8px; font-size: 0.85em; font-weight: 500; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(0,214,50,0.3)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">
                    <span style="font-size: 1.1em;">💵</span> Cash App
                </a>
                <a href="https://paypal.me/SteveVogt" target="_blank" style="text-decoration: none; display: flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #0070BA 0%, #003087 100%); color: white; padding: 8px 14px; border-radius: 8px; font-size: 0.85em; font-weight: 500; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(0,112,186,0.3)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">
                    <span style="font-size: 1.1em;">🅿️</span> PayPal
                </a>
                <a href="https://venmo.com/u/SteveVogt" target="_blank" style="text-decoration: none; display: flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #3D95CE 0%, #008CFF 100%); color: white; padding: 8px 14px; border-radius: 8px; font-size: 0.85em; font-weight: 500; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(0,140,255,0.3)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">
                    <span style="font-size: 1.1em;">💜</span> Venmo
                </a>
                <button onclick="toggleBitcoin()" style="display: flex; align-items: center; gap: 6px; background: linear-gradient(135deg, #F7931A 0%, #E2820A 100%); color: white; padding: 8px 14px; border-radius: 8px; font-size: 0.85em; font-weight: 500; border: none; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 12px rgba(247,147,26,0.3)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">
                    <span style="font-size: 1.1em;">₿</span> Bitcoin
                </button>
            </div>
        </div>
        <div id="bitcoinSection" style="display: none; margin-top: 12px; padding: 12px; background: var(--bg-secondary); border-radius: var(--radius-sm); border: 1px solid #F7931A33;">
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <code id="btcAddress" style="font-size: 0.8em; word-break: break-all; color: var(--text-primary); background: var(--bg-input); padding: 8px 12px; border-radius: var(--radius-sm); flex: 1;">bc1qpdex8jrvyj3lh7q56av2k53nrh7u63s6t65uer</code>
                <button onclick="copyBitcoin()" class="btn btn-secondary" style="font-size: 0.8em; padding: 6px 10px;">📋 Copy</button>
            </div>
        </div>
    </div>
    
    <!-- Running Notice -->
    <div style="margin-top: 24px; padding: 12px 16px; background: var(--bg-secondary); border-radius: var(--radius-md); border: 1px solid var(--border-color); display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 1.1em;">💡</span>
        <span style="font-size: 0.85em; color: var(--text-secondary);">
            <strong style="color: var(--text-primary);">Note:</strong> This app runs locally on your computer. 
            Keep it running (or minimized to tray) and connected to the internet for scheduled price checks and email alerts to work.
        </span>
    </div>
    
    <!-- Terms and Privacy -->
    <div style="margin-top: 32px; padding: 24px; background: var(--bg-card); border-radius: var(--radius-md); border: 1px solid var(--border-color); text-align: center;">
        <h3 style="font-size: 1em; font-weight: 600; margin-bottom: 16px; color: var(--text-primary);">Terms of Use & Privacy</h3>
        <div style="font-size: 0.85em; color: var(--text-secondary); line-height: 1.8; max-width: 800px; margin: 0 auto; text-align: left;">
            <p style="margin-bottom: 12px;">
                <strong>Disclaimer:</strong> This software is provided "AS IS" without warranty of any kind. 
                The author(s) shall not be liable for any damages arising from use of this software. 
                Use at your own risk.
            </p>
            <p style="margin-bottom: 12px;">
                <strong>Terms of Service:</strong> Automated access to airline websites may violate their terms of service. 
                This tool is provided for personal, educational purposes only. By using this software, you accept full 
                responsibility for compliance with all applicable terms and laws. The author is not responsible for 
                any account restrictions, legal issues, or other consequences resulting from use.
            </p>
            <p style="margin-bottom: 12px;">
                <strong>Privacy:</strong> All data is stored locally on your computer. No information is collected, 
                shared, or transmitted to external servers. For email alerts, we require a Google App Password 
                (not your regular Gmail password) - this can be revoked anytime from your Google Account without 
                affecting your main password.
            </p>
            <p style="margin-bottom: 12px;">
                <strong>Security:</strong> This application runs only on your local machine (localhost) and is not 
                accessible from the network. No external connections are made except to Delta.com for price checks 
                and your email server for alerts (if configured).
            </p>
        </div>
        <div style="margin-top: 16px; font-size: 0.75em; color: var(--text-muted);">
            <div style="margin-bottom: 8px;">© <span id="copyrightYear">2026</span> Delta Flight Tracker v{{ version }}</div>
            <div>Developed by <a href="mailto:steve@stevevogt.com" style="color: var(--text-muted);">Steve Vogt</a></div>
            <div style="margin-top: 8px;">Not affiliated with Delta Air Lines, Inc.</div>
        </div>
    </div>
</div>

<!-- Confirmation Modal (themed) -->
<div class="modal-overlay" id="confirmModal">
    <div class="modal">
        <h3 id="confirmTitle">Confirm Action</h3>
        <p id="confirmMessage">Are you sure?</p>
        <div class="modal-btns">
            <button class="btn btn-secondary" onclick="closeConfirmModal()">Cancel</button>
            <button class="btn btn-danger" id="confirmBtn" onclick="executeConfirmAction()">Confirm</button>
        </div>
    </div>
</div>

<!-- Progress Overlay -->
<div class="progress-overlay" id="progressOverlay">
    <div class="progress-plane">✈️</div>
    <div class="progress-text" id="progressText">Checking prices...</div>
    <div class="progress-subtext" id="progressSubtext">This runs in the background - feel free to use other apps!</div>
    <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
</div>

<!-- Toast Container -->
<div class="toast-container" id="toastContainer"></div>

<script>
// Tab switching
function showTab(tab) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector(`.tab:nth-child(${tab === 'flights' ? 1 : tab === 'history' ? 2 : 3})`).classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
}

// Toast notifications
function showToast(type, title, message, duration = 5000) {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    container.appendChild(toast);
    if (duration > 0) {
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
}

// Themed confirmation modal
let pendingConfirmAction = null;

function showConfirmModal(title, message, actionCallback, btnText = 'Confirm', btnClass = 'btn-danger') {
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    const btn = document.getElementById('confirmBtn');
    btn.textContent = btnText;
    btn.className = 'btn ' + btnClass;
    pendingConfirmAction = actionCallback;
    document.getElementById('confirmModal').classList.add('active');
}

function closeConfirmModal() {
    document.getElementById('confirmModal').classList.remove('active');
    pendingConfirmAction = null;
}

function executeConfirmAction() {
    if (pendingConfirmAction) {
        pendingConfirmAction();
    }
    closeConfirmModal();
}

// Close modal on escape or backdrop click
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeConfirmModal(); });
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('confirmModal').addEventListener('click', e => {
        if (e.target.id === 'confirmModal') closeConfirmModal();
    });
});

// Delete flight with themed confirmation
function deleteFlight(fid, route) {
    showConfirmModal(
        '🗑️ Delete Flight',
        `Permanently delete "${route}"? This cannot be undone.`,
        () => {
            fetch('/remove/' + fid)
                .then(() => {
                    showToast('success', 'Deleted', 'Flight permanently deleted');
                    setTimeout(() => location.reload(), 1000);
                })
                .catch(e => showToast('error', 'Error', e.toString()));
        },
        'Delete',
        'btn-danger'
    );
}

// Progress overlay
function showProgress(text, subtext) {
    document.getElementById('progressText').textContent = text || 'Checking prices...';
    document.getElementById('progressSubtext').textContent = subtext || 'Feel free to use other apps!';
    document.getElementById('progressFill').style.width = '0%';
    document.getElementById('progressOverlay').classList.add('active');
}

function updateProgress(percent, text) {
    document.getElementById('progressFill').style.width = percent + '%';
    if (text) document.getElementById('progressText').textContent = text;
}

function hideProgress() {
    document.getElementById('progressOverlay').classList.remove('active');
}

function autoCheckAll() {
    const btn = document.getElementById('checkAllBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Checking...';
    
    showProgress('Checking all flights...', 'Each flight takes 30-60 seconds. Running in background...');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress = Math.min(progress + 2, 90);
        updateProgress(progress);
    }, 1000);
    
    fetch('/auto-check-all', {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            clearInterval(interval);
            updateProgress(100);
            setTimeout(hideProgress, 500);
            
            if (d.success) {
                showToast('success', '🎉 Check Complete!', d.message || 'All prices updated');
                setTimeout(() => location.reload(), 2000);
            } else {
                showToast('error', 'Error', d.error || 'Check failed');
                btn.disabled = false;
                btn.textContent = '🤖 Auto Check All';
            }
        })
        .catch(e => {
            clearInterval(interval);
            hideProgress();
            showToast('error', 'Error', e.toString());
            btn.disabled = false;
            btn.textContent = '🤖 Auto Check All';
        });
}

function autoCheckOne(fid) {
    const btn = event.target;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';
    
    showProgress('Checking flight...', 'This takes 30-60 seconds. Opening browser in background...');
    
    let progress = 0;
    const interval = setInterval(() => {
        progress = Math.min(progress + 3, 90);
        updateProgress(progress);
    }, 1000);
    
    fetch('/auto-check/' + fid, {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            clearInterval(interval);
            updateProgress(100);
            setTimeout(hideProgress, 500);
            
            if (d.success) {
                showToast('success', '✅ Price Found!', d.message);
                setTimeout(() => location.reload(), 2000);
            } else {
                showToast('error', 'Check Failed', d.error || 'Could not find price');
                btn.disabled = false;
                btn.textContent = '🤖';
            }
        })
        .catch(e => {
            clearInterval(interval);
            hideProgress();
            showToast('error', 'Error', e.toString());
            btn.disabled = false;
            btn.textContent = '🤖';
        });
}

function toggleSchedule(fid, newState) {
    const btn = event.target;
    btn.disabled = true;
    btn.style.opacity = '0.5';
    
    fetch('/toggle-schedule/' + fid, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({scheduled: newState})
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            // Update button appearance
            if (d.scheduled) {
                btn.className = 'toggle-btn toggle-on';
                btn.textContent = '✓ Scheduled';
                btn.title = 'Click to remove from scheduled checks';
                btn.onclick = () => toggleSchedule(fid, false);
            } else {
                btn.className = 'toggle-btn toggle-off';
                btn.textContent = '+ Add';
                btn.title = 'Click to add to scheduled checks';
                btn.onclick = () => toggleSchedule(fid, true);
            }
            // Show prominent feedback
            showToast('success', 
                      d.scheduled ? '✓ Added to Scheduled Checks' : '✓ Removed from Scheduled Checks', 
                      d.scheduled ? 'This flight will be checked automatically at your scheduled times' : 'This flight will only be checked manually',
                      4000);
        } else {
            showToast('error', 'Could Not Update', d.error || 'Please try again');
        }
        btn.disabled = false;
        btn.style.opacity = '1';
    })
    .catch(e => {
        showToast('error', 'Error', 'Network error');
        btn.disabled = false;
        btn.style.opacity = '1';
    });
}

function toggleScreenshot(historyId) {
    const el = document.getElementById('screenshot-' + historyId);
    if (el) el.classList.toggle('visible');
}

function testEmail() {
    fetch('/test-email', {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast('success', 'Email Sent!', 'Check your inbox');
            } else {
                showToast('error', 'Email Failed', d.error || 'Check settings');
            }
        });
}

function testDeltaLogin() {
    // Check if credentials appear to be saved
    const passwordHint = document.querySelector('#delta_password + .help-text');
    if (passwordHint && !passwordHint.textContent.includes('saved')) {
        showToast('warning', 'Save First!', 'Click "Save Delta Login" before testing');
        return;
    }
    
    showToast('info', 'Testing Login...', 'Opening browser - this takes 30+ seconds');
    fetch('/test-delta-login', {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast('success', 'Login Successful!', d.message || 'Delta credentials work');
            } else {
                showToast('error', 'Login Failed', d.error || 'Check credentials');
            }
        })
        .catch(e => {
            showToast('error', 'Test Error', 'Check console for details');
        });
}

// Copy Bitcoin address
function copyBitcoin() {
    const address = document.getElementById('btcAddress').textContent;
    navigator.clipboard.writeText(address).then(() => {
        showToast('success', 'Copied!', 'Bitcoin address copied to clipboard');
    }).catch(() => {
        showToast('error', 'Copy Failed', 'Please copy manually');
    });
}

// Toggle Bitcoin section visibility
function toggleBitcoin() {
    const section = document.getElementById('bitcoinSection');
    section.style.display = section.style.display === 'none' ? 'block' : 'none';
}

// Dismiss connection alerts
function dismissAlerts() {
    fetch('/dismiss_alerts', { method: 'POST' })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                const banner = document.getElementById('alertBanner');
                if (banner) banner.style.display = 'none';
            }
        });
}

// Archive flight
function archiveFlight(fid) {
    showConfirmModal(
        '📦 Archive Flight',
        'Archive this flight? You can restore it later from the archived view.',
        () => {
            fetch('/archive/' + fid, {method: 'POST'})
                .then(r => r.json())
                .then(d => {
                    if (d.success) {
                        showToast('success', 'Archived', 'Flight moved to archive');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showToast('error', 'Error', d.error || 'Could not archive');
                    }
                })
                .catch(e => showToast('error', 'Error', e.toString()));
        },
        'Archive',
        'btn-primary'
    );
}

// Restore flight
function restoreFlight(fid) {
    fetch('/restore/' + fid, {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast('success', 'Restored', 'Flight restored from archive');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('error', 'Error', d.error || 'Could not restore');
            }
        })
        .catch(e => showToast('error', 'Error', e.toString()));
}

// Claim savings (when user rebooks at lower price)
function claimSavings(fid, amount) {
    showConfirmModal(
        '💰 Claim Savings',
        'Did you rebook this flight at the lower price? This will log $' + amount.toLocaleString() + ' as actual savings you claimed.',
        () => {
            fetch('/claim-savings/' + fid, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({amount: amount})
            })
                .then(r => r.json())
                .then(d => {
                    if (d.success) {
                        showToast('success', '💰 Savings Claimed!', 'Logged $' + amount.toLocaleString() + ' in savings');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showToast('error', 'Error', d.error || 'Could not claim savings');
                    }
                })
                .catch(e => showToast('error', 'Error', e.toString()));
        },
        'Claim Savings',
        'btn-primary'
    );
}

// Duplicate flight (same route, prompts for new dates)
function duplicateFlight(fid) {
    fetch('/duplicate/' + fid, {method: 'POST'})
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                showToast('success', 'Duplicated', 'Flight copied! Redirecting to edit dates...');
                setTimeout(() => location.href = '/edit/' + d.new_id, 1000);
            } else {
                showToast('error', 'Error', d.error || 'Could not duplicate');
            }
        })
        .catch(e => showToast('error', 'Error', e.toString()));
}

// Export data
function exportData() {
    window.location.href = '/export/json';
    showToast('info', 'Downloading', 'Your flight data is being exported...');
}

// Import data
function importData(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const formData = new FormData();
    formData.append('file', file);
    
    showToast('info', 'Importing', 'Processing your file...');
    
    fetch('/import', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            let message = d.message;
            if (d.errors && d.errors.length > 0) {
                message += '<br><br>Errors:<br>' + d.errors.slice(0, 5).join('<br>');
            }
            showToast('success', 'Import Complete', message, 8000);
            setTimeout(() => location.reload(), 2000);
        } else {
            showToast('error', 'Import Failed', d.error);
        }
        // Reset file input
        event.target.value = '';
    })
    .catch(e => {
        showToast('error', 'Import Failed', e.toString());
        event.target.value = '';
    });
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ignore if typing in input/textarea
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    
    switch(e.key.toLowerCase()) {
        case 'n':
            document.querySelector('input[name="origin"]')?.focus();
            e.preventDefault();
            break;
        case 'r':
            location.reload();
            break;
        case 'f':
            showTab('flights');
            e.preventDefault();
            break;
        case 'h':
            showTab('history');
            e.preventDefault();
            break;
        case 's':
            if (!e.ctrlKey && !e.metaKey) {
                showTab('settings');
                e.preventDefault();
            }
            break;
        case '?':
            showKeyboardHelp();
            e.preventDefault();
            break;
    }
});

// Table sorting
let currentSort = { column: null, direction: 'asc' };

function sortTable(column) {
    const table = document.getElementById('flightsTable');
    const tbody = document.getElementById('flightsTableBody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    // Toggle direction if same column
    if (currentSort.column === column) {
        currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
    } else {
        currentSort.column = column;
        currentSort.direction = 'asc';
    }
    
    // Update header classes
    document.querySelectorAll('th.sortable').forEach(th => {
        th.classList.remove('sort-asc', 'sort-desc');
    });
    const header = document.querySelector(`th[data-sort="${column}"]`);
    if (header) {
        header.classList.add(currentSort.direction === 'asc' ? 'sort-asc' : 'sort-desc');
    }
    
    // Sort rows
    rows.sort((a, b) => {
        let aVal, bVal;
        
        switch(column) {
            case 'route':
                aVal = a.dataset.route || '';
                bVal = b.dataset.route || '';
                break;
            case 'date':
                aVal = a.dataset.date || '';
                bVal = b.dataset.date || '';
                break;
            case 'price':
                aVal = parseFloat(a.dataset.price) || 0;
                bVal = parseFloat(b.dataset.price) || 0;
                break;
            case 'lowest':
                aVal = parseFloat(a.dataset.lowest) || 0;
                bVal = parseFloat(b.dataset.lowest) || 0;
                break;
            default:
                return 0;
        }
        
        if (typeof aVal === 'string') {
            const cmp = aVal.localeCompare(bVal);
            return currentSort.direction === 'asc' ? cmp : -cmp;
        } else {
            const cmp = aVal - bVal;
            return currentSort.direction === 'asc' ? cmp : -cmp;
        }
    });
    
    // Re-append rows in sorted order
    rows.forEach(row => tbody.appendChild(row));
}

// Move row up/down
function moveRow(fid, direction) {
    fetch('/reorder/' + fid + '/' + direction, { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showToast('error', 'Error', data.error || 'Failed to reorder');
            }
        })
        .catch(e => showToast('error', 'Error', e.toString()));
}

function showKeyboardHelp() {
    const shortcuts = `
        <div style="text-align:left;">
        <strong>⌨️ Keyboard Shortcuts:</strong><br><br>
        <strong>N</strong> - New flight<br>
        <strong>F</strong> - Flights tab<br>
        <strong>H</strong> - History tab<br>
        <strong>S</strong> - Settings tab<br>
        <strong>R</strong> - Reload page<br>
        <strong>?</strong> - Show shortcuts
        </div>
    `;
    showToast('info', '', shortcuts, 8000);
}

// Update copyright year automatically
try {
    document.getElementById('copyrightYear').textContent = new Date().getFullYear();
} catch(e) { console.error('Copyright year error:', e); }

// Check for updates on page load (with delay to not slow initial load)
setTimeout(() => {
    fetch('/check-updates')
        .then(r => r.json())
        .then(data => {
            if (data.update_available) {
                const banner = document.getElementById('updateBanner');
                document.getElementById('latestVersion').textContent = data.latest_version;
                document.getElementById('updateLink').href = data.download_url;
                banner.style.display = 'flex';
            }
        })
        .catch(() => {}); // Silently fail if can't check
}, 2000);

// Debug: Log that script loaded successfully
console.log('Delta Flight Tracker JS loaded successfully');
</script>
</body>
</html>
'''

# =============================================================================
# ROUTES
# =============================================================================

def delta_url(f):
    """Template helper to generate Delta URL."""
    if not f.get('dep_date'):
        return '#'  # Return placeholder if no date
    return generate_delta_url(f['origin'], f['dest'], f['dep_date'], f.get('ret_date'), 
                               f.get('miles', 0), f.get('exclude_basic', 0))

def format_time(timestamp_str, settings=None):
    """Format time based on user preference (12h or 24h)."""
    if not timestamp_str:
        return ''
    if settings is None:
        settings = load_settings()
    
    try:
        # Extract time portion (assumes format like "2024-01-15 14:30" or "01-15 14:30")
        if 'T' in timestamp_str:
            time_part = timestamp_str.split('T')[1][:5]  # Get HH:MM
        elif ' ' in timestamp_str:
            time_part = timestamp_str.split(' ')[1][:5]  # Get HH:MM
        else:
            time_part = timestamp_str[:5]  # Assume it's just time
        
        if settings.get('time_format_24h', False):
            return time_part  # Return as-is for 24h format
        else:
            # Convert to 12h format
            hour, minute = map(int, time_part.split(':'))
            period = 'AM' if hour < 12 else 'PM'
            hour_12 = hour % 12
            if hour_12 == 0:
                hour_12 = 12
            return f"{hour_12}:{minute:02d} {period}"
    except:
        return timestamp_str

def days_until(date_str):
    """Calculate days until a date."""
    if not date_str:
        return None
    try:
        dep_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        today = datetime.now().date()
        delta = (dep_date - today).days
        return delta
    except:
        return None

@app.context_processor
def utility_processor():
    settings = load_settings()
    return dict(delta_url=delta_url, format_time=format_time, settings=settings, days_until=days_until)

@app.route('/')
def index():
    try:
        all_flights = get_flights()
        active_flights = [f for f in all_flights if not f.get('archived')]
        archived_flights = [f for f in all_flights if f.get('archived')]
        return render_template_string(HTML, 
            flights=all_flights,
            active_flights=active_flights,
            archived_flights=archived_flights,
            history=get_history(),
            settings=load_settings(),
            stats=get_statistics(),
            connection_failures=get_connection_failure_count(),
            version=APP_VERSION,
            edit_flight=None
        )
    except Exception as e:
        logger.error(f"Error rendering index: {e}")
        import traceback
        traceback.print_exc()
        return f"Error loading page: {str(e)}", 500

@app.route('/edit/<int:fid>')
def edit(fid):
    try:
        flight = get_flight(fid)
        if not flight:
            return redirect(url_for('index'))
        all_flights = get_flights()
        active_flights = [f for f in all_flights if not f.get('archived')]
        archived_flights = [f for f in all_flights if f.get('archived')]
        return render_template_string(HTML,
            flights=all_flights,
            active_flights=active_flights,
            archived_flights=archived_flights,
            history=get_history(),
            settings=load_settings(),
            stats=get_statistics(),
            connection_failures=get_connection_failure_count(),
            version=APP_VERSION,
            edit_flight=flight
        )
    except Exception as e:
        logger.error(f"Error rendering edit page: {e}")
        import traceback
        traceback.print_exc()
        return f"Error loading page: {str(e)}", 500

@app.route('/add', methods=['POST'])
def add():
    try:
        # Check flight limit (bot detection)
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM flights WHERE archived = 0')
        active_count = c.fetchone()[0]
        conn.close()
        
        if active_count >= MAX_FLIGHTS_LIMIT:
            return f'''
            <div style="font-family: sans-serif; max-width: 500px; margin: 40px auto; padding: 20px; background: #fff3cd; border-radius: 8px; border: 1px solid #ffc107;">
                <h2 style="color: #856404; margin-top: 0;">⚠️ Flight Limit Reached</h2>
                <p>You have <strong>{active_count}</strong> active flights, which is the maximum allowed.</p>
                <p><strong>Why the limit?</strong> To avoid bot detection by Delta, we limit how many flights can be tracked. 
                With {MAX_FLIGHTS_LIMIT} flights checked ~20 minutes apart, the daily check takes about {MAX_FLIGHTS_LIMIT * 20} minutes.</p>
                <p><strong>What to do:</strong></p>
                <ul>
                    <li>Archive flights you no longer need to track</li>
                    <li>Remove completed trips</li>
                </ul>
                <a href="/" style="display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;">← Back to Flights</a>
            </div>
            ''', 400
        
        # Validate inputs
        origin = request.form.get('origin', '').upper().strip()
        dest = request.form.get('dest', '').upper().strip()
        dep_date = request.form.get('dep_date', '').strip()
        ret_date = request.form.get('ret_date', '').strip()
        
        if not validate_airport_code(origin):
            logger.warning(f"Invalid origin code: {origin}")
            return f"Invalid origin airport code: {origin}. Must be 3 letters.", 400
        
        if not validate_airport_code(dest):
            logger.warning(f"Invalid destination code: {dest}")
            return f"Invalid destination airport code: {dest}. Must be 3 letters.", 400
        
        if not validate_date(dep_date):
            logger.warning(f"Invalid departure date: {dep_date}")
            return f"Invalid departure date: {dep_date}. Must be today or future.", 400
        
        if ret_date and not validate_date(ret_date):
            logger.warning(f"Invalid return date: {ret_date}")
            return f"Invalid return date: {ret_date}. Must be today or future.", 400
        
        # Parse paid price/miles with safe error handling
        paid_price = None
        paid_miles = None
        try:
            pp = request.form.get('paid_price', '').strip()
            if pp:
                paid_price = float(pp)
        except (ValueError, TypeError):
            pass
        
        try:
            pm = request.form.get('paid_miles', '').strip()
            if pm:
                paid_miles = int(float(pm))  # Handle "45000.0" format
        except (ValueError, TypeError):
            pass
        
        alert_below_paid = 1 if 'alert_below_paid' in request.form else 0
        
        # Parse claimed_savings
        claimed_savings = None
        try:
            cs = request.form.get('claimed_savings', '').strip()
            if cs:
                claimed_savings = float(cs)
        except (ValueError, TypeError):
            pass
        
        # Validate prices are positive if provided
        if paid_price is not None and paid_price < 0:
            paid_price = abs(paid_price)  # Auto-correct negative prices
        if paid_miles is not None and paid_miles < 0:
            paid_miles = abs(paid_miles)
        if claimed_savings is not None and claimed_savings < 0:
            claimed_savings = abs(claimed_savings)
        
        # Truncate notes to prevent abuse
        notes = request.form.get('notes', '').strip()[:500]
        
        # Insert flight
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('''INSERT INTO flights (origin, destination, dep_date, ret_date, dep_time, 
                     search_miles, exclude_basic, active, scheduled, notes, 
                     paid_price, paid_miles, alert_below_paid, claimed_savings, created)
                     VALUES (?,?,?,?,?,?,?,1,?,?,?,?,?,?,?)''',
                  (origin, dest, dep_date,
                   ret_date or None,
                   build_time_string(request.form),
                   1 if 'miles' in request.form else 0,
                   1 if 'exclude_basic' in request.form else 0,
                   1 if 'scheduled' in request.form else 0,
                   notes,
                   paid_price,
                   paid_miles,
                   alert_below_paid,
                   claimed_savings,
                   datetime.now().isoformat()))
        conn.commit()
        conn.close()
        logger.info(f"Added flight {origin}-{dest}")
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error adding flight: {e}")
        import traceback
        traceback.print_exc()
        return f"Error adding flight: {str(e)}", 500

@app.route('/update/<int:fid>', methods=['POST'])
def update(fid):
    try:
        # Validate inputs
        origin = request.form.get('origin', '').upper()
        dest = request.form.get('dest', '').upper()
        dep_date = request.form.get('dep_date', '')
        ret_date = request.form.get('ret_date', '')
        
        if not validate_airport_code(origin):
            logger.warning(f"Invalid origin code: {origin}")
            return f"Invalid origin airport code: {origin}. Must be 3 letters.", 400
        
        if not validate_airport_code(dest):
            logger.warning(f"Invalid destination code: {dest}")
            return f"Invalid destination airport code: {dest}. Must be 3 letters.", 400
        
        if not validate_date(dep_date):
            logger.warning(f"Invalid departure date: {dep_date}")
            return f"Invalid departure date: {dep_date}. Must be today or future.", 400
        
        if ret_date and not validate_date(ret_date):
            logger.warning(f"Invalid return date: {ret_date}")
            return f"Invalid return date: {ret_date}. Must be today or future.", 400
        
        # Parse paid price/miles/savings with safe error handling
        paid_price = None
        paid_miles = None
        claimed_savings = None
        
        try:
            pp = request.form.get('paid_price', '').strip()
            if pp:
                paid_price = float(pp)
        except (ValueError, TypeError):
            pass
        
        try:
            pm = request.form.get('paid_miles', '').strip()
            if pm:
                paid_miles = int(float(pm))
        except (ValueError, TypeError):
            pass
        
        try:
            cs = request.form.get('claimed_savings', '').strip()
            if cs:
                claimed_savings = float(cs)
        except (ValueError, TypeError):
            pass
        
        alert_below_paid = 1 if 'alert_below_paid' in request.form else 0
        
        # Truncate notes to prevent abuse
        notes = request.form.get('notes', '').strip()[:500]
        
        # Update flight
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('''UPDATE flights SET origin=?, destination=?, dep_date=?, ret_date=?, 
                     dep_time=?, search_miles=?, exclude_basic=?, active=?, scheduled=?, notes=?,
                     paid_price=?, paid_miles=?, alert_below_paid=?, claimed_savings=? WHERE id=?''',
                  (origin, dest, dep_date,
                   ret_date or None,
                   build_time_string(request.form),
                   1 if 'miles' in request.form else 0,
                   1 if 'exclude_basic' in request.form else 0,
                   1 if 'active' in request.form else 0,
                   1 if 'scheduled' in request.form else 0,
                   notes,
                   paid_price,
                   paid_miles,
                   alert_below_paid,
                   claimed_savings,
                   fid))
        conn.commit()
        conn.close()
        logger.info(f"Updated flight {fid}")
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error updating flight: {e}")
        import traceback
        traceback.print_exc()
        return f"Error updating flight: {str(e)}", 500

@app.route('/remove/<int:fid>', methods=['GET', 'POST'])
def remove(fid):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('DELETE FROM price_history WHERE flight_id=?', (fid,))
        c.execute('DELETE FROM flights WHERE id=?', (fid,))
        conn.commit()
        conn.close()
        conn.close()
        
        # Return JSON for AJAX calls, redirect for direct browser requests
        if request.headers.get('Accept', '').find('application/json') != -1 or request.is_json:
            return jsonify({'success': True})
        return redirect(url_for('index'))
    except Exception as e:
        logger.error(f"Error removing flight {fid}: {e}")
        if request.headers.get('Accept', '').find('application/json') != -1 or request.is_json:
            return jsonify({'success': False, 'error': str(e)})
        return redirect(url_for('index'))

@app.route('/toggle-schedule/<int:fid>', methods=['POST'])
def toggle_schedule(fid):
    try:
        data = request.get_json()
        new_state = data.get('scheduled', False)
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('UPDATE flights SET scheduled=? WHERE id=?', (1 if new_state else 0, fid))
        conn.commit()
        
        # Verify the update
        c.execute('SELECT scheduled FROM flights WHERE id=?', (fid,))
        row = c.fetchone()
        conn.close()
        
        if row:
            return jsonify({'success': True, 'scheduled': bool(row[0])})
        else:
            return jsonify({'success': False, 'error': 'Flight not found'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/save-price/<int:fid>', methods=['POST'])
def save_price_route(fid):
    try:
        data = request.get_json()
        price = float(data.get('price', 0))
        if not validate_price(price):
            return jsonify({'success': False, 'error': 'Invalid price'})
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('''SELECT last_price, lowest_price, highest_price, search_miles, origin, destination, 
                     dep_date, ret_date, dep_time, exclude_basic, paid_price, paid_miles, alert_below_paid 
                     FROM flights WHERE id=?''', (fid,))
        row = c.fetchone()
        
        if not row:
            conn.close()
            return jsonify({'success': False, 'error': 'Flight not found'})
        
        (old_price, lowest, highest, is_miles, origin, dest, dep_date, ret_date, 
         dep_time, exclude_basic, paid_price, paid_miles, alert_below_paid) = row
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        new_lowest = min(price, lowest) if lowest else price
        new_highest = max(price, highest) if highest else price
        
        c.execute('UPDATE flights SET last_price=?, lowest_price=?, highest_price=?, last_checked=? WHERE id=?',
                  (price, new_lowest, new_highest, now, fid))
        c.execute('INSERT INTO price_history (flight_id, price, checked_at, check_type) VALUES (?,?,?,?)',
                  (fid, price, now, 'manual'))
        conn.commit()
        
        # Get most recent screenshot for this flight (if any)
        c.execute('''SELECT screenshot FROM price_history 
                     WHERE flight_id=? AND screenshot IS NOT NULL 
                     ORDER BY id DESC LIMIT 1''', (fid,))
        screenshot_row = c.fetchone()
        screenshot_path = None
        if screenshot_row and screenshot_row[0]:
            screenshot_path = SCREENSHOTS_DIR / screenshot_row[0]
        
        conn.close()
        
        # Email on price drop (with threshold check)
        if old_price and price < old_price and should_send_alert(old_price, price):
            # Check if "only alert below paid" is enabled
            should_alert = True
            if alert_below_paid:
                # Compare against paid price (cash) or paid miles depending on search type
                compare_to = paid_miles if is_miles else paid_price
                if compare_to is not None and price >= compare_to:
                    # Price hasn't dropped below what user paid, skip alert
                    should_alert = False
                    logger.info(f"Skipping alert for {origin}-{dest}: price {price} not below paid {compare_to}")
            
            if should_alert:
                sym = "" if is_miles else "$"
                unit = " miles" if is_miles else ""
                diff = old_price - price
                percent = (diff / old_price) * 100
                
                # Add paid price comparison to subject/body if available
                compare_to = paid_miles if is_miles else paid_price
                if compare_to is not None and price < compare_to:
                    savings_vs_paid = compare_to - price
                    subject = f"✈️ Price Drop Below Paid! {origin}-{dest} now {sym}{price:,.0f}{unit}"
                    body = f"Flight: {origin} → {dest}\nDepart: {dep_date}\nYou Paid: {sym}{compare_to:,.0f}{unit}\nNow: {sym}{price:,.0f}{unit}\nBelow Paid By: {sym}{savings_vs_paid:,.0f}{unit}\n\nPrevious Price: {sym}{old_price:,.0f}{unit}"
                else:
                    subject = f"✈️ Price Drop: {origin}-{dest} now {sym}{price:,.0f}{unit}"
                    body = f"Flight: {origin} → {dest}\nDepart: {dep_date}\nWas: {sym}{old_price:,.0f}{unit}\nNow: {sym}{price:,.0f}{unit}\nSaved: {sym}{diff:,.0f} ({percent:.1f}%)"
                
                # Generate booking URL
                booking_url = generate_delta_url(origin, dest, dep_date, ret_date, is_miles, exclude_basic)
                
                send_email(subject, body, screenshot_path=screenshot_path, booking_url=booking_url)
                logger.info(f"Price drop alert sent for {origin}-{dest}: ${diff:.0f} ({percent:.1f}%)")
        
        sym = "" if is_miles else "$"
        unit = " miles" if is_miles else ""
        return jsonify({'success': True, 'message': f'{sym}{price:,.0f}{unit} recorded for {origin}→{dest}'})
    except Exception as e:
        logger.error(f"Error saving price: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/save-settings', methods=['POST'])
def save_settings_route():
    settings = load_settings()
    
    if request.form.get('settings_type') == 'schedule':
        settings['schedule_enabled'] = 'schedule_enabled' in request.form
        settings['schedule_time'] = request.form.get('schedule_time', '03:00')
    elif request.form.get('settings_type') == 'display':
        settings['time_format_24h'] = 'time_format_24h' in request.form
    elif request.form.get('settings_type') == 'thresholds':
        settings['price_alert_min_dollars'] = int(request.form.get('price_alert_min_dollars', 0))
        settings['price_alert_min_percent'] = int(request.form.get('price_alert_min_percent', 0))
    elif request.form.get('settings_type') == 'maintenance':
        settings['screenshot_retention_days'] = int(request.form.get('screenshot_retention_days', 30))
        settings['max_screenshots_per_flight'] = int(request.form.get('max_screenshots_per_flight', 50))
        settings['auto_backup_enabled'] = 'auto_backup_enabled' in request.form
        settings['backup_retention_days'] = int(request.form.get('backup_retention_days', 7))
    elif request.form.get('settings_type') == 'reminders':
        settings['reminders_enabled'] = 'reminders_enabled' in request.form
        # Parse comma-separated days
        reminder_days_str = request.form.get('reminder_days_before', '7,2')
        try:
            settings['reminder_days_before'] = [int(d.strip()) for d in reminder_days_str.split(',') if d.strip()]
        except:
            settings['reminder_days_before'] = [7, 2]
    elif request.form.get('settings_type') == 'advanced':
        settings['warn_on_duplicate'] = 'warn_on_duplicate' in request.form
    else:
        settings['email_to'] = request.form.get('email_to', '')
        settings['email_from'] = request.form.get('email_from', '')
        if request.form.get('email_password'):
            # Validate App Password format (16 letters, spaces allowed)
            app_password = request.form.get('email_password', '').replace(' ', '')
            if len(app_password) != 16 or not app_password.isalpha():
                logger.warning(f"Invalid App Password format: {len(app_password)} chars")
                # Still save it but log warning - user might have a valid reason
            settings['email_password'] = request.form.get('email_password')
    
    save_settings(settings)
    return redirect(url_for('index'))

@app.route('/test-delta-login', methods=['POST'])
def test_delta_login():
    """Test Delta login credentials."""
    settings = load_settings()
    
    if not settings.get('delta_username') or not settings.get('delta_password_encoded'):
        return jsonify({'success': False, 'error': 'Username and password required'})
    
    try:
        # Import and call the test function from tracker
        import importlib
        import sys
        if 'tracker' in sys.modules:
            importlib.reload(sys.modules['tracker'])
        import tracker
        
        # Decode password
        password = base64.b64decode(settings['delta_password_encoded']).decode()
        
        success, message = tracker.test_delta_login(
            settings['delta_username'],
            password,
            settings.get('delta_last_name', '')
        )
        return jsonify({'success': success, 'message': message, 'error': None if success else message})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/screenshot/<int:history_id>')
def get_screenshot(history_id):
    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
    c = conn.cursor()
    c.execute('SELECT screenshot FROM price_history WHERE id=?', (history_id,))
    row = c.fetchone()
    conn.close()
    
    if row and row[0]:
        screenshot_path = SCREENSHOTS_DIR / row[0]
        if screenshot_path.exists():
            return send_file(screenshot_path, mimetype='image/png')
    
    return '', 404

@app.route('/archive/<int:fid>', methods=['POST'])
def archive_flight(fid):
    """Archive a flight (soft delete)."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('UPDATE flights SET archived = 1, active = 0 WHERE id = ?', (fid,))
        conn.commit()
        conn.close()
        logger.info(f"Flight {fid} archived")
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error archiving flight {fid}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/restore/<int:fid>', methods=['POST'])
def restore_flight(fid):
    """Restore an archived flight."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('UPDATE flights SET archived = 0, active = 1 WHERE id = ?', (fid,))
        conn.commit()
        conn.close()
        logger.info(f"Flight {fid} restored from archive")
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error restoring flight {fid}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/reorder/<int:fid>/<direction>', methods=['POST'])
def reorder_flight(fid, direction):
    """Move a flight up or down in the list."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        
        # Get current flight's sort_order
        c.execute('SELECT sort_order FROM flights WHERE id = ?', (fid,))
        row = c.fetchone()
        if not row:
            conn.close()
            return jsonify({'success': False, 'error': 'Flight not found'})
        
        current_order = row[0] or 0
        
        # Get all active non-archived flights sorted by sort_order
        c.execute('SELECT id, COALESCE(sort_order, 0) as sort_order FROM flights WHERE archived = 0 ORDER BY sort_order, dep_date')
        all_flights = c.fetchall()
        
        # Find index of current flight
        current_idx = None
        for i, (flight_id, _) in enumerate(all_flights):
            if flight_id == fid:
                current_idx = i
                break
        
        if current_idx is None:
            conn.close()
            return jsonify({'success': False, 'error': 'Flight not in list'})
        
        # Calculate swap index
        if direction == 'up' and current_idx > 0:
            swap_idx = current_idx - 1
        elif direction == 'down' and current_idx < len(all_flights) - 1:
            swap_idx = current_idx + 1
        else:
            conn.close()
            return jsonify({'success': True, 'message': 'Already at boundary'})
        
        swap_flight_id = all_flights[swap_idx][0]
        
        # Swap sort_orders
        c.execute('UPDATE flights SET sort_order = ? WHERE id = ?', (swap_idx, fid))
        c.execute('UPDATE flights SET sort_order = ? WHERE id = ?', (current_idx, swap_flight_id))
        
        conn.commit()
        conn.close()
        logger.info(f"Reordered flight {fid} {direction}")
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error reordering flight {fid}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/claim-savings/<int:fid>', methods=['POST'])
def claim_savings(fid):
    """Log that user actually claimed/rebooked at lower price."""
    try:
        data = request.get_json()
        amount = float(data.get('amount', 0))
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('UPDATE flights SET claimed_savings = ?, claimed_at = ? WHERE id = ?',
                  (amount, datetime.now().isoformat(), fid))
        conn.commit()
        conn.close()
        logger.info(f"Flight {fid}: Claimed savings of {amount}")
        return jsonify({'success': True, 'amount': amount})
    except Exception as e:
        logger.error(f"Error claiming savings for flight {fid}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/duplicate/<int:fid>', methods=['POST'])
def duplicate_flight(fid):
    """Duplicate a flight (same route, resets prices/dates)."""
    try:
        # Check flight limit first
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM flights WHERE archived = 0')
        active_count = c.fetchone()[0]
        conn.close()
        
        if active_count >= MAX_FLIGHTS_LIMIT:
            return jsonify({
                'success': False, 
                'error': f'Flight limit reached ({active_count}/{MAX_FLIGHTS_LIMIT}). Archive or remove flights first.'
            })
        
        flight = get_flight(fid)
        if not flight:
            return jsonify({'success': False, 'error': 'Flight not found'})
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        c.execute('''INSERT INTO flights (origin, destination, dep_date, ret_date, dep_time, 
                     search_miles, exclude_basic, active, scheduled, notes, created)
                     VALUES (?,?,?,?,?,?,?,1,1,?,?)''',
                  (flight['origin'], flight['dest'], flight['dep_date'], flight['ret_date'],
                   flight.get('dep_time', ''), flight.get('miles', 0), flight.get('exclude_basic', 0),
                   flight.get('notes', '') + ' (copy)', datetime.now().isoformat()))
        new_id = c.lastrowid
        conn.commit()
        conn.close()
        logger.info(f"Duplicated flight {fid} to {new_id}")
        return jsonify({'success': True, 'new_id': new_id})
    except Exception as e:
        logger.error(f"Error duplicating flight {fid}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/export/json')
def export_json():
    """Export all flight data as JSON."""
    try:
        flights = get_flights()
        output = json.dumps(flights, indent=2)
        return Response(
            output,
            mimetype='application/json',
            headers={'Content-Disposition': f'attachment;filename=flights_{datetime.now().strftime("%Y%m%d")}.json'}
        )
    except Exception as e:
        logger.error(f"Export error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/import', methods=['POST'])
@rate_limit(max_requests=5, window=3600)  # Max 5 imports per hour
def import_data():
    """Import flight data from JSON file with security validation and duplicate detection."""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'})
        
        if not file.filename.endswith('.json'):
            return jsonify({'success': False, 'error': 'Only JSON files are supported'})
        
        content = file.read().decode('utf-8')
        
        # Security: Limit file size (Flask already enforces MAX_CONTENT_LENGTH)
        if len(content) > MAX_FILE_UPLOAD_SIZE:
            return jsonify({'success': False, 'error': 'File too large'})
        
        data = json.loads(content)
        
        if not isinstance(data, list):
            return jsonify({'success': False, 'error': 'Invalid file format - expected array of flights'})
        
        # Security: Limit number of flights to import
        if len(data) > MAX_IMPORT_FLIGHTS:
            return jsonify({'success': False, 'error': f'Too many flights. Max {MAX_IMPORT_FLIGHTS} allowed.'})
        
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        c = conn.cursor()
        count = 0
        duplicates = 0
        errors = []
        
        for i, flight in enumerate(data):
            try:
                # Validate required fields
                origin = flight.get('origin', '').upper()
                dest = flight.get('dest', '').upper()
                dep_date = flight.get('dep_date', '')
                ret_date = flight.get('ret_date', '') or None
                dep_time = flight.get('dep_time', '') or ''
                miles = int(flight.get('miles', 0))
                
                if not validate_airport_code(origin):
                    errors.append(f"Flight {i+1}: Invalid origin code: {origin}")
                    continue
                if not validate_airport_code(dest):
                    errors.append(f"Flight {i+1}: Invalid destination code: {dest}")
                    continue
                if not validate_date(dep_date):
                    errors.append(f"Flight {i+1}: Invalid or past date: {dep_date}")
                    continue
                
                # Check for duplicate (same route, dates, time, and miles type)
                c.execute('''SELECT id FROM flights 
                             WHERE origin=? AND destination=? AND dep_date=? 
                             AND (ret_date=? OR (ret_date IS NULL AND ? IS NULL))
                             AND dep_time=? AND search_miles=?''',
                         (origin, dest, dep_date, ret_date, ret_date, dep_time, miles))
                
                existing = c.fetchone()
                if existing:
                    duplicates += 1
                    continue
                
                # Sanitize notes field
                notes = str(flight.get('notes', ''))[:500]  # Limit length
                
                # Insert flight
                c.execute('''INSERT INTO flights 
                           (origin, destination, dep_date, ret_date, dep_time, 
                            search_miles, exclude_basic, notes, created, archived)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                         (origin, dest, dep_date, 
                          ret_date,
                          dep_time,
                          miles,
                          int(flight.get('exclude_basic', 0)),
                          notes,
                          datetime.now().isoformat(),
                          int(flight.get('archived', 0))))
                
                if c.rowcount > 0:
                    count += 1
            except Exception as e:
                errors.append(f"Flight {i+1} ({origin}-{dest}): {str(e)}")
        
        conn.commit()
        conn.close()
        
        logger.info(f"Imported {count}/{len(data)} flights, {duplicates} duplicates, {len(errors)} errors")
        
        message = f"Imported {count} flight{'s' if count != 1 else ''}"
        if duplicates > 0:
            message += f", {duplicates} duplicate{'s' if duplicates != 1 else ''} skipped"
        if errors:
            message += f", {len(errors)} error{'s' if len(errors) != 1 else ''}"
        
        return jsonify({
            'success': True, 
            'count': count,
            'duplicates': duplicates,
            'message': message,
            'errors': errors[:10] if errors else []  # Return first 10 errors
        })
    except json.JSONDecodeError:
        logger.error("Import failed: Invalid JSON")
        return jsonify({'success': False, 'error': 'Invalid JSON file'})
    except Exception as e:
        logger.error(f"Import error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/test-email', methods=['POST'])
@rate_limit(max_requests=5, window=300)  # Max 5 test emails per 5 minutes
def test_email():
    """Send a test email to verify configuration."""
    try:
        settings = load_settings()
        
        # Validate App Password format
        app_password = settings.get('email_password', '').replace(' ', '')
        if app_password and (len(app_password) != 16 or not app_password.isalpha()):
            return jsonify({
                'success': False, 
                'error': 'Invalid App Password format. It should be 16 letters (like "abcd efgh ijkl mnop"). Make sure you\'re using a Google App Password, not your regular Gmail password. Create one at: myaccount.google.com/apppasswords'
            })
        
        subject = "✅ Delta Flight Tracker - Test Email"
        body = """This is a test email from your Delta Flight Tracker.

If you received this, your email settings are configured correctly!

System Status:
- Email notifications: Working ✓
- SMTP connection: Successful
- Timestamp: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        if send_email(subject, body, settings):
            return jsonify({'success': True, 'message': 'Test email sent successfully!'})
        else:
            return jsonify({'success': False, 'error': 'Failed to send email. Make sure you\'re using a Google App Password (16 letters), not your regular password.'})
    except Exception as e:
        logger.error(f"Test email error: {e}")
        error_msg = str(e)
        if 'authentication' in error_msg.lower() or 'credential' in error_msg.lower():
            error_msg += ' — Make sure you\'re using a Google App Password, not your regular Gmail password.'
        return jsonify({'success': False, 'error': error_msg})

@app.route('/check-duplicate', methods=['POST'])
def check_duplicate():
    """Check if a flight already exists."""
    try:
        data = request.get_json()
        origin = data.get('origin', '').upper()
        dest = data.get('dest', '').upper()
        dep_date = data.get('dep_date', '')
        
        result = check_duplicate_flight(origin, dest, dep_date)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Duplicate check error: {e}")
        return jsonify({'exists': False, 'error': str(e)})

@app.route('/price-history/<int:fid>')
def price_history(fid):
    """Get price history data for a flight."""
    try:
        history = get_price_history_data(fid)
        return jsonify({'success': True, 'history': history})
    except Exception as e:
        logger.error(f"Price history error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/templates')
def get_templates_route():
    """Get all flight templates."""
    try:
        templates = get_templates()
        return jsonify({'success': True, 'templates': templates})
    except Exception as e:
        logger.error(f"Get templates error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/create-template', methods=['POST'])
def create_template_route():
    """Create a new flight template."""
    try:
        data = request.get_json()
        template_id = create_template(
            name=data.get('name', ''),
            origin=data.get('origin', ''),
            dest=data.get('dest', ''),
            dep_time=data.get('dep_time', ''),
            search_miles=data.get('miles', 0),
            exclude_basic=data.get('exclude_basic', 0),
            notes=data.get('notes', '')
        )
        if template_id:
            return jsonify({'success': True, 'id': template_id})
        else:
            return jsonify({'success': False, 'error': 'Failed to create template'})
    except Exception as e:
        logger.error(f"Create template error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/delete-template/<int:tid>', methods=['POST'])
def delete_template_route(tid):
    """Delete a flight template."""
    try:
        if delete_template(tid):
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': 'Failed to delete template'})
    except Exception as e:
        logger.error(f"Delete template error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/bulk-date-shift', methods=['POST'])
def bulk_date_shift_route():
    """Shift dates for multiple flights."""
    try:
        data = request.get_json()
        flight_ids = data.get('flight_ids', [])
        days_offset = int(data.get('days_offset', 0))
        
        if not flight_ids:
            return jsonify({'success': False, 'error': 'No flights selected'})
        
        if days_offset == 0:
            return jsonify({'success': False, 'error': 'Days offset cannot be zero'})
        
        updated = bulk_date_shift(flight_ids, days_offset)
        return jsonify({'success': True, 'updated': updated})
    except Exception as e:
        logger.error(f"Bulk date shift error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/cleanup-screenshots', methods=['POST'])
def cleanup_screenshots_route():
    """Manually trigger screenshot cleanup."""
    try:
        deleted = cleanup_screenshots()
        return jsonify({'success': True, 'deleted': deleted})
    except Exception as e:
        logger.error(f"Screenshot cleanup error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/backup-database', methods=['POST'])
def backup_database_route():
    """Manually trigger database backup."""
    try:
        if backup_database():
            return jsonify({'success': True, 'message': 'Database backed up successfully'})
        else:
            return jsonify({'success': False, 'error': 'Backup failed'})
    except Exception as e:
        logger.error(f"Backup error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/dismiss_alerts', methods=['POST'])
def dismiss_alerts_route():
    """Dismiss all connection/system alerts."""
    try:
        dismiss_all_alerts()
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Dismiss alerts error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/system-status')
def system_status_route():
    """Get current system status."""
    try:
        status = get_system_status()
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        logger.error(f"System status error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/check-updates')
def check_updates_route():
    """Check for app updates from GitHub."""
    try:
        result = check_for_updates()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Update check error: {e}")
        return jsonify({'update_available': False, 'error': str(e)})

@app.route('/check-reminders', methods=['POST'])
def check_reminders_route():
    """Manually trigger reminder check."""
    try:
        sent = check_departure_reminders()
        return jsonify({'success': True, 'sent': sent})
    except Exception as e:
        logger.error(f"Reminder check error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/auto-check-all', methods=['POST'])
@rate_limit(max_requests=10, window=3600)  # Max 10 auto-checks per hour
def auto_check_all():
    """Auto-check all active scheduled flights."""
    try:
        import importlib
        sys.path.insert(0, str(BASE_PATH))
        
        # Import tracker module
        if 'tracker' in sys.modules:
            import tracker
            importlib.reload(tracker)
        else:
            import tracker
        
        # Get flights to check
        conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Get active scheduled flights
        c.execute('''SELECT id, origin, destination, search_miles FROM flights 
                     WHERE active=1 AND scheduled=1 AND archived=0 AND dep_date >= ? 
                     ORDER BY dep_date''', (today,))
        flights = c.fetchall()
        conn.close()
        
        if not flights:
            return jsonify({'success': True, 'message': 'No active flights to check'})
        
        settings = load_settings()
        use_headless = settings.get('use_headless_mode', True)
        
        checked = 0
        errors = 0
        
        for i, flight in enumerate(flights):
            fid = flight['id']
            origin = flight['origin']
            dest = flight['destination']
            is_miles = flight['search_miles']
            
            try:
                logger.info(f"Auto-check-all: Checking {origin}->{dest} (id={fid})")
                result = tracker.check_flight_auto(fid, headless=use_headless, take_screenshot=True)
                
                if len(result) == 3:
                    price, error, screenshot_file = result
                else:
                    price, error = result
                    screenshot_file = None
                
                if price:
                    # Update database
                    conn = sqlite3.connect(DB_PATH, timeout=DB_CONNECTION_TIMEOUT)
                    c = conn.cursor()
                    c.execute('SELECT last_price, lowest_price, highest_price FROM flights WHERE id=?', (fid,))
                    row = c.fetchone()
                    lowest = row[1] if row else None
                    highest = row[2] if row else None
                    
                    new_lowest = min(price, lowest) if lowest else price
                    new_highest = max(price, highest) if highest else price
                    
                    c.execute('''UPDATE flights SET last_price=?, lowest_price=?, highest_price=?, last_checked=? 
                                 WHERE id=?''', (price, new_lowest, new_highest, datetime.now().isoformat(), fid))
                    
                    # Save to history
                    screenshot_data = None
                    if screenshot_file and Path(screenshot_file).exists():
                        with open(screenshot_file, 'rb') as f:
                            screenshot_data = f.read()
                    
                    c.execute('''INSERT INTO price_history (flight_id, price, checked_at, check_type, screenshot) 
                                 VALUES (?, ?, ?, 'auto', ?)''', (fid, price, datetime.now().isoformat(), screenshot_data))
                    conn.commit()
                    conn.close()
                    
                    checked += 1
                    logger.info(f"Auto-check-all: {origin}->{dest} = {'${:,.0f}'.format(price) if not is_miles else '{:,.0f} mi'.format(price)}")
                else:
                    errors += 1
                    logger.warning(f"Auto-check-all: {origin}->{dest} failed: {error}")
                    
            except Exception as e:
                errors += 1
                logger.error(f"Auto-check-all: Error checking {origin}->{dest}: {e}")
            
            # Delay between flights (except after last one)
            if i < len(flights) - 1:
                import random
                # Jittered delay: 80% chance 8-25s, 20% chance 25-45s
                if random.random() < 0.8:
                    delay = random.uniform(8, 25)
                else:
                    delay = random.uniform(25, 45)
                time.sleep(delay)
        
        message = f'Checked {checked}/{len(flights)} flights'
        if errors:
            message += f' ({errors} errors)'
        
        return jsonify({'success': True, 'message': message, 'checked': checked, 'total': len(flights)})
        
    except Exception as e:
        logger.error(f"Auto-check-all error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/auto-check/<int:fid>', methods=['POST'])
def auto_check_one(fid):
    """Auto-check a single flight with screenshot."""
    try:
        flight = get_flight(fid)
        if not flight:
            return jsonify({'success': False, 'error': 'Flight not found'})
        
        import sys
        import importlib
        sys.path.insert(0, str(BASE_PATH))
        
        # Force reload to get latest tracker.py
        if 'tracker' in sys.modules:
            import tracker
            importlib.reload(tracker)
        else:
            import tracker
        
        # Run headless (invisible) by default for cleaner user experience
        settings = load_settings()
        use_headless = settings.get('use_headless_mode', True)  # Default to headless (invisible)
        
        result = tracker.check_flight_auto(fid, headless=use_headless, take_screenshot=True)
        
        # Handle both old (2-tuple) and new (3-tuple) return formats
        if len(result) == 3:
            price, error, screenshot_file = result
        else:
            price, error = result
            screenshot_file = None
        
        # If bot detection in headless mode, suggest trying visible mode
        if not price and error and 'Bot detection' in str(error) and use_headless:
            return jsonify({
                'success': False, 
                'error': 'Bot detection in headless mode. Try disabling "Headless Mode" in Settings for better results.'
            })
        
        # Track connection failures for alert banner
        if not price and error:
            error_lower = str(error).lower()
            if any(term in error_lower for term in ['connection', 'timeout', 'network', 'unreachable', 'dns', 'refused', 'reset']):
                add_system_alert('connection_failure', f'Price check failed: {error}')
        
        if price:
            tracker.save_price(fid, price, 'auto', screenshot=screenshot_file)
            sym = '' if flight['miles'] else '$'
            unit = ' miles' if flight['miles'] else ''
            return jsonify({'success': True, 'message': f'{sym}{price:,.0f}{unit} for {flight["origin"]}→{flight["dest"]}'})
        else:
            return jsonify({'success': False, 'error': error or 'Could not find price'})
    except Exception as e:
        import traceback
        traceback.print_exc()
        # Track connection-related exceptions
        error_str = str(e).lower()
        if any(term in error_str for term in ['connection', 'timeout', 'network', 'unreachable', 'dns', 'refused', 'reset']):
            add_system_alert('connection_failure', f'Price check error: {e}')
        return jsonify({'success': False, 'error': str(e)})

# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    init_db()
    print("\n" + "="*50)
    print("Delta Flight Tracker v7")
    print("="*50)
    print("\n📍 Open: http://deltapricetracker.local:5000")
    print("🛑 Stop: Ctrl+C")
    print("\n✨ New in v7:")
    print("  • Toast notifications (no popups!)")
    print("  • Screenshot proof for each price check")
    print("  • Email & scheduling settings in UI")
    print("  • Fixed Delta links with search params")
    print("  • Runs in background - use your PC!")
    print("  • Background scheduler for daily checks!\n")
    
    # Start the background scheduler
    start_scheduler()
    
    app.run(debug=True, host='127.0.0.1', port=5000)
