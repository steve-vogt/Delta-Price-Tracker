# Delta Flight Tracker - Mac

## Quick Start

### First Time Setup

1. **Double-click `install_mac.command`**
   - This installs Python packages and the browser
   - Takes 2-5 minutes
   - You may be asked for your password (for the optional friendly URL)

2. **If you get "unidentified developer" warning:**
   - Right-click the file → Open → Click "Open" in the dialog
   - Or: System Preferences → Security & Privacy → Click "Open Anyway"

### Running the App

1. **Double-click `run_mac.command`**
2. Browser opens automatically
3. **To stop:** Press `Ctrl+C` in the Terminal window, or just close it

## Files

```
DeltaFlightTracker/
├── install_mac.command  ← Run once to set up
├── run_mac.command      ← Run to start the app
├── web_ui.py            ← Main application
├── tracker.py           ← Price checker
└── README_MAC.md        ← This file
```

## Requirements

- macOS 10.15 or later
- Python 3.8+ (install from python.org or via `brew install python3`)

## Data Location

Your flight data is stored in:
```
~/Library/Application Support/DeltaFlightTracker/
```

Or in the same folder as the app files.

## Troubleshooting

### "Permission denied" when running scripts
```bash
chmod +x install_mac.command run_mac.command
```

### Port 5000 already in use
```bash
# Find what's using port 5000
lsof -i :5000

# Kill it
kill -9 <PID>
```

### Browser not opening
Manually go to: http://127.0.0.1:5000

## Differences from Windows Version

- No system tray icon (runs in Terminal instead)
- No auto-start at login (you can add it manually via System Preferences → Users & Groups → Login Items)
- Press Ctrl+C to stop (instead of tray menu)

## Manual Command Line Usage

```bash
# Install dependencies
pip3 install flask pillow playwright
python3 -m playwright install firefox

# Run the app
cd /path/to/DeltaFlightTracker
python3 -c "import web_ui; web_ui.init_db(); web_ui.app.run(port=5000)"
```
