#!/usr/bin/env python3
"""
Delta Flight Price Tracker - Core Engine
Based on the WORKING original code with Playwright Firefox
"""

import sqlite3
import os
import sys
import time
import re
import random
import smtplib
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from datetime import datetime, timedelta
from pathlib import Path

# =============================================================================
# PATH CONFIGURATION
# =============================================================================

if getattr(sys, 'frozen', False):
    BASE_PATH = Path(os.path.dirname(sys.executable))
else:
    BASE_PATH = Path(__file__).parent

DB_PATH = BASE_PATH / "flights.db"
COOLDOWN_FILE = BASE_PATH / ".cooldown"
SETTINGS_FILE = BASE_PATH / "settings.json"
SCREENSHOTS_DIR = BASE_PATH / "screenshots"

SCREENSHOTS_DIR.mkdir(exist_ok=True)

# =============================================================================
# SETTINGS
# =============================================================================

DEFAULT_SETTINGS = {
    "email_from": "",
    "email_password": "",
    "email_to": "",
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "cooldown_hours": 12,
}

# =============================================================================
# SELECTOR CONFIGURATION (Remote-updatable with local fallback)
# =============================================================================

# Local fallback selectors - used if remote fetch fails
DEFAULT_SELECTORS = {
    "version": "1.0.0",
    "miles_toggle": "#shopWithMiles",
    "flight_grid": '[id^="flight-results-grid-"]',
    "departure_time": ".flight-schedule__operation-time",
    "cash_price": ".mach-revenue-price__whole",
    "miles_price": ".mach-miles-price__whole",
    "find_button": "button:has-text('Find Flights'), button:has-text('FIND FLIGHTS'), button[type='submit']",
    "continue_button": "button:has-text('CONTINUE')",
    "checkbox_general": 'input[type="checkbox"]',
}

# Remote config URL (GitHub Gist or similar) - set to None to disable
REMOTE_SELECTOR_URL = "https://gist.githubusercontent.com/steve-vogt/raw/delta-selectors.json"

# Cache file for remote selectors
SELECTOR_CACHE_FILE = BASE_PATH / ".selector_cache.json"
SELECTOR_CACHE_MAX_AGE = 3600 * 6  # 6 hours

def get_selectors():
    """
    Get CSS selectors for Delta.com scraping.
    Tries remote config first, falls back to local defaults.
    Caches remote config to avoid repeated fetches.
    """
    # Try cached selectors first
    try:
        if SELECTOR_CACHE_FILE.exists():
            cache_age = time.time() - SELECTOR_CACHE_FILE.stat().st_mtime
            if cache_age < SELECTOR_CACHE_MAX_AGE:
                with open(SELECTOR_CACHE_FILE, 'r') as f:
                    cached = json.load(f)
                    if cached.get('selectors'):
                        return cached['selectors']
    except Exception:
        pass
    
    # Try remote fetch (non-blocking, with short timeout)
    if REMOTE_SELECTOR_URL:
        try:
            import urllib.request
            req = urllib.request.Request(
                REMOTE_SELECTOR_URL,
                headers={'User-Agent': 'DeltaPriceTracker/2.3'}
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                remote = json.loads(response.read().decode())
                if remote.get('selectors'):
                    # Cache it
                    try:
                        with open(SELECTOR_CACHE_FILE, 'w') as f:
                            json.dump({'selectors': remote['selectors'], 'fetched': time.time()}, f)
                    except Exception:
                        pass
                    print(f"   [Selectors: remote v{remote['selectors'].get('version', '?')}]")
                    return remote['selectors']
        except Exception as e:
            # Silent fail - use local defaults
            pass
    
    # Use local defaults
    return DEFAULT_SELECTORS.copy()

# Global selector instance (loaded once per run)
SELECTORS = None

def selectors():
    """Get selectors (lazy-loaded singleton)."""
    global SELECTORS
    if SELECTORS is None:
        SELECTORS = get_selectors()
    return SELECTORS

def load_settings():
    """Load settings from JSON file."""
    try:
        if SETTINGS_FILE.exists():
            settings = json.loads(SETTINGS_FILE.read_text())
            for key, value in DEFAULT_SETTINGS.items():
                settings.setdefault(key, value)
            return settings
    except Exception as e:
        print(f"Error loading settings: {e}")
    return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    """Save settings to JSON file."""
    try:
        SETTINGS_FILE.write_text(json.dumps(settings, indent=2))
        return True
    except Exception as e:
        print(f"Error saving settings: {e}")
        return False

# =============================================================================
# DATABASE
# =============================================================================

def init_db():
    """Initialize the SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS flights (
        id INTEGER PRIMARY KEY,
        origin TEXT NOT NULL,
        destination TEXT NOT NULL,
        dep_date TEXT NOT NULL,
        ret_date TEXT,
        dep_time TEXT DEFAULT '',
        search_miles INTEGER DEFAULT 0,
        exclude_basic INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        scheduled INTEGER DEFAULT 1,
        last_price REAL,
        lowest_price REAL,
        last_checked TEXT,
        created TEXT
    )''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY,
        flight_id INTEGER,
        price REAL,
        checked_at TEXT,
        check_type TEXT DEFAULT 'manual',
        error TEXT,
        screenshot TEXT,
        FOREIGN KEY (flight_id) REFERENCES flights(id)
    )''')
    
    # Add columns if missing (for upgrades)
    try:
        c.execute('ALTER TABLE flights ADD COLUMN scheduled INTEGER DEFAULT 1')
    except:
        pass
    try:
        c.execute('ALTER TABLE price_history ADD COLUMN screenshot TEXT')
    except:
        pass
    
    conn.commit()
    conn.close()

def get_flight(flight_id):
    """Get a single flight by ID."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM flights WHERE id=?', (flight_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def save_price(flight_id, price, check_type='manual', error=None, screenshot=None):
    """Save a price check result."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.now().isoformat()
    
    c.execute('''INSERT INTO price_history (flight_id, price, checked_at, check_type, error, screenshot)
                 VALUES (?, ?, ?, ?, ?, ?)''', 
              (flight_id, price, now, check_type, error, screenshot))
    
    if price:
        c.execute('SELECT lowest_price FROM flights WHERE id=?', (flight_id,))
        row = c.fetchone()
        lowest = row[0] if row and row[0] else price
        new_lowest = min(lowest, price)
        
        c.execute('''UPDATE flights SET last_price=?, lowest_price=?, last_checked=? WHERE id=?''',
                  (price, new_lowest, now, flight_id))
    else:
        c.execute('UPDATE flights SET last_checked=? WHERE id=?', (now, flight_id))
    
    conn.commit()
    conn.close()

# =============================================================================
# COOLDOWN MANAGEMENT
# =============================================================================

def is_on_cooldown():
    if not COOLDOWN_FILE.exists():
        return False
    try:
        cooldown_until = datetime.fromisoformat(COOLDOWN_FILE.read_text().strip())
        if datetime.now() < cooldown_until:
            return True
        COOLDOWN_FILE.unlink()
    except:
        pass
    return False

def get_cooldown_remaining():
    if not COOLDOWN_FILE.exists():
        return None
    try:
        cooldown_until = datetime.fromisoformat(COOLDOWN_FILE.read_text().strip())
        remaining = cooldown_until - datetime.now()
        if remaining.total_seconds() > 0:
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            return f"{hours}h {minutes}m"
    except:
        pass
    return None

def set_cooldown():
    settings = load_settings()
    hours = settings.get('cooldown_hours', 12)
    cooldown_until = datetime.now() + timedelta(hours=hours)
    COOLDOWN_FILE.write_text(cooldown_until.isoformat())
    print(f"\n⚠️  Bot detection triggered. Auto-check paused for {hours}h.")

def reset_cooldown():
    if COOLDOWN_FILE.exists():
        COOLDOWN_FILE.unlink()
        return True
    return False

# =============================================================================
# EMAIL
# =============================================================================

def send_email(subject, body, screenshot_path=None):
    """Send an email notification."""
    settings = load_settings()
    email_from = settings.get('email_from', '')
    email_password = settings.get('email_password', '')
    email_to = settings.get('email_to', '')
    
    if not email_from or not email_password or not email_to:
        print("   Email not configured")
        return False
    
    try:
        msg = MIMEMultipart()
        msg['From'] = email_from
        msg['To'] = email_to
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))
        
        if screenshot_path and Path(screenshot_path).exists():
            with open(screenshot_path, 'rb') as img_file:
                img = MIMEImage(img_file.read(), name=Path(screenshot_path).name)
                img.add_header('Content-Disposition', 'attachment', 
                               filename=Path(screenshot_path).name)
                msg.attach(img)
        
        server = settings.get('smtp_server', 'smtp.gmail.com')
        port = settings.get('smtp_port', 587)
        
        with smtplib.SMTP(server, port) as smtp:
            smtp.starttls()
            smtp.login(email_from, email_password)
            smtp.send_message(msg)
        
        print(f"   ✓ Email sent to {email_to}")
        return True
    except Exception as e:
        print(f"   ✗ Email failed: {e}")
        return False

# =============================================================================
# PRICE CHECKING - WORKING LOGIC FROM ORIGINAL
# =============================================================================

def check_flight_auto(flight_id, headless=True, take_screenshot=True):
    """
    Check flight price using Playwright Firefox.
    This is the WORKING logic from the original tracker.py
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("Playwright not installed. Run: pip install playwright && playwright install firefox")
        return None, "Playwright not installed", None
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''SELECT origin, destination, dep_date, ret_date, dep_time, search_miles, exclude_basic
                 FROM flights WHERE id=?''', (flight_id,))
    f = c.fetchone()
    conn.close()
    
    if not f:
        return None, "Flight not found", None
    
    origin = f['origin']
    dest = f['destination']
    dep_date = f['dep_date']
    ret_date = f['ret_date']
    dep_time = f['dep_time'] or ''
    use_miles = f['search_miles']
    exclude_basic = f['exclude_basic']
    
    # Single debug file - overwrites each time
    debug_png = SCREENSHOTS_DIR / "debug_latest.png"
    debug_html = SCREENSHOTS_DIR / "debug_latest.html"
    
    search_type = "Miles" if use_miles else "Cash"
    
    print(f"\n{'='*60}")
    print(f"[AUTO] #{flight_id}: {origin}→{dest} | {search_type}")
    print(f"       Dates: {dep_date}" + (f" to {ret_date}" if ret_date else " (one-way)"))
    if dep_time:
        print(f"       Target time: {dep_time}")
    print(f"{'='*60}")
    
    # Build search URL - using MM/DD/YYYY format like the working version
    dep_dt = datetime.strptime(dep_date, "%Y-%m-%d")
    dep_formatted = dep_dt.strftime("%m/%d/%Y")
    
    trip_type = "ROUND_TRIP" if ret_date else "ONE_WAY"
    
    url_params = [
        "action=findFlights",
        f"tripType={trip_type}",
        f"originCity={origin}",
        f"destinationCity={dest}",
        f"departureDate={dep_formatted}",
        "departureTime=AT",
        "paxCount=1",
        "searchByCabin=true",
        "deltaOnlySearch=false",
        "awardTravel=false",  # We'll check the box manually for miles
        "flexDates=false",    # Explicitly disable flexible dates
        "flexAirport=false",  # Explicitly disable flexible airports
    ]
    
    if ret_date:
        ret_dt = datetime.strptime(ret_date, "%Y-%m-%d")
        ret_formatted = ret_dt.strftime("%m/%d/%Y")
        url_params.append(f"returnDate={ret_formatted}")
        url_params.append("returnTime=AT")
    
    if exclude_basic:
        url_params.append("cabinFareClass=MAIN")
    
    search_url = "https://www.delta.com/flight-search/book-a-flight?" + "&".join(url_params)
    print(f"   URL: {search_url[:80]}...")
    
    price = None
    found_grid_id = None
    screenshot_file = None
    
    with sync_playwright() as p:
        try:
            print("   Launching Firefox...")
            browser = p.firefox.launch(headless=headless, slow_mo=100)
            context = browser.new_context(
                viewport={"width": 1400, "height": 900},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0"
            )
            page = context.new_page()
            
            # Load Delta search page
            print("   Loading search page...")
            page.goto(search_url, wait_until="domcontentloaded", timeout=60000)
            time.sleep(5)
            
            # For miles search: check the "Shop with Miles" box and click Find Flights
            if use_miles:
                print("   Enabling 'Shop with Miles'...")
                try:
                    # STEP 1: First, uncheck ALL flexible dates checkboxes BEFORE touching miles
                    page.evaluate("""() => {
                        const flexSelectors = [
                            '#flexibleDates',
                            '#chkFlexDate', 
                            'input[name="flexibleDates"]',
                            'input[id*="flexible"]',
                            'input[id*="Flexible"]',
                            'input[name*="flexible"]',
                            'input[name*="Flexible"]',
                            '[data-cy*="flexible"]'
                        ];
                        for (const sel of flexSelectors) {
                            const boxes = document.querySelectorAll(sel);
                            boxes.forEach(box => {
                                if (box && box.checked) {
                                    box.click();
                                    console.log('PRE-UNCHECK flexible:', sel, box.id);
                                }
                            });
                        }
                    }""")
                    time.sleep(0.5)
                    
                    # STEP 2: Click the miles checkbox
                    page.evaluate("""() => {
                        const milesBox = document.querySelector('#shopWithMiles');
                        if (milesBox && !milesBox.checked) {
                            milesBox.click();
                            console.log('Clicked Shop with Miles');
                        }
                    }""")
                    time.sleep(1)
                    
                    # STEP 3: AGAIN uncheck flexible dates (in case clicking miles re-checked it)
                    page.evaluate("""() => {
                        const flexSelectors = [
                            '#flexibleDates',
                            '#chkFlexDate', 
                            'input[name="flexibleDates"]',
                            'input[id*="flexible"]',
                            'input[id*="Flexible"]'
                        ];
                        for (const sel of flexSelectors) {
                            const boxes = document.querySelectorAll(sel);
                            boxes.forEach(box => {
                                if (box && box.checked) {
                                    box.click();
                                    console.log('POST-UNCHECK flexible:', sel, box.id);
                                }
                            });
                        }
                    }""")
                    time.sleep(0.5)
                    
                    # STEP 4: Check final states
                    checkbox_states = page.evaluate("""() => {
                        const milesBox = document.querySelector('#shopWithMiles');
                        const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
                        let flexChecked = false;
                        allCheckboxes.forEach(cb => {
                            if ((cb.id && cb.id.toLowerCase().includes('flex')) ||
                                (cb.name && cb.name.toLowerCase().includes('flex'))) {
                                if (cb.checked) flexChecked = true;
                            }
                        });
                        return {
                            milesChecked: milesBox ? milesBox.checked : null,
                            flexChecked: flexChecked
                        };
                    }""")
                    print(f"   Checkbox states: miles={checkbox_states.get('milesChecked')}, flex={checkbox_states.get('flexChecked')}")
                    
                    # Click Find Flights button
                    find_btn = page.locator("button:has-text('Find Flights'), button:has-text('FIND FLIGHTS'), button[type='submit']").first
                    if find_btn.count() > 0:
                        find_btn.click()
                        print("   Searching for award flights...")
                        time.sleep(25)
                    else:
                        print("   ⚠ Could not find 'Find Flights' button")
                        time.sleep(20)
                except Exception as e:
                    print(f"   Miles setup error: {e}")
                    time.sleep(20)
            else:
                # Cash search - need to click Find Flights button
                print("   Clicking Find Flights for cash search...")
                try:
                    # First uncheck flexible dates if checked
                    page.evaluate("""() => {
                        const flexSelectors = ['#flexibleDates', 'input[name="flexibleDates"]', '#chkFlexDate', 'input[id*="flexible"]'];
                        for (const sel of flexSelectors) {
                            const boxes = document.querySelectorAll(sel);
                            boxes.forEach(box => {
                                if (box && box.checked) {
                                    box.click();
                                }
                            });
                        }
                    }""")
                    time.sleep(0.5)
                    
                    # Click Find Flights button
                    find_btn = page.locator("button:has-text('Find Flights'), button:has-text('FIND FLIGHTS'), button[type='submit']").first
                    if find_btn.count() > 0:
                        find_btn.click()
                        print("   Searching for flights...")
                        time.sleep(25)
                    else:
                        print("   ⚠ Could not find 'Find Flights' button - waiting...")
                        time.sleep(20)
                except Exception as e:
                    print(f"   ⚠ Cash search error: {e}")
                    time.sleep(20)
            
            # Check if we landed on flexible dates page instead of results
            page_url = page.url
            page_text_check = page.inner_text("body").lower()
            
            if "flexible-dates" in page_url or "flexible dates" in page_text_check or "price calendar" in page_text_check:
                print("   📅 Landed on Flexible Dates page - clicking through to results...")
                try:
                    page.screenshot(path=str(SCREENSHOTS_DIR / "debug_flex_dates.png"))
                    
                    # Click CONTINUE button
                    clicked = page.evaluate("""() => {
                        const allButtons = document.querySelectorAll('button');
                        for (const btn of allButtons) {
                            if (btn.innerText.trim() === 'CONTINUE') {
                                btn.click();
                                return 'clicked';
                            }
                        }
                        return 'not_found';
                    }""")
                    
                    if 'clicked' in clicked:
                        print("   ✓ Clicked CONTINUE")
                        time.sleep(20)
                    else:
                        continue_btn = page.locator("button:has-text('CONTINUE')").first
                        if continue_btn.count() > 0:
                            continue_btn.click()
                            print("   ✓ Clicked CONTINUE via Playwright")
                            time.sleep(20)
                except Exception as e:
                    print(f"   ⚠ Could not click through flexible dates: {e}")
            
            # Save debug screenshot
            page.screenshot(path=str(debug_png), full_page=False)
            
            # Get page text for checks
            page_text = page.inner_text("body")
            
            # Check for bot detection
            if any(x in page_text.lower() for x in ['access denied', 'blocked', 'captcha', 'unusual traffic']):
                print("   ❌ Bot detection!")
                set_cooldown()
                context.close()
                browser.close()
                return None, "Bot detection", None
            
            # Check for no results
            if "no results were found" in page_text.lower() or "ROF4002" in page_text:
                print("   ❌ No results found")
                context.close()
                browser.close()
                return None, "No results found", None
            
            # Save debug HTML
            try:
                debug_html.write_text(page.content(), encoding='utf-8')
            except:
                pass
            
            # =====================
            # Extract PRICE
            # =====================
            print("   Extracting price...")
            
            target_flight_price = None
            
            if dep_time:
                print(f"   Looking for flight at {dep_time}...")
                
                time_str = dep_time.lower().strip()
                is_miles = use_miles
                
                # JavaScript to find specific flight and price
                js_result = page.evaluate(f"""() => {{
                    const targetTime = '{time_str}';
                    const searchMiles = {'true' if is_miles else 'false'};
                    
                    const grids = document.querySelectorAll('[id^="flight-results-grid-"]');
                    
                    for (const grid of grids) {{
                        const timeEls = grid.querySelectorAll('.flight-schedule__operation-time');
                        if (timeEls.length === 0) continue;
                        
                        const depTime = timeEls[0].innerText.trim().toLowerCase();
                        
                        if (depTime === targetTime || depTime.includes(targetTime) || 
                            targetTime.includes(depTime.replace(/\\s/g, ''))) {{
                            
                            const gridText = grid.innerText;
                            
                            if (searchMiles) {{
                                // Look for miles price patterns
                                const milesMatch = gridText.match(/(\\d{{1,3}}(?:,\\d{{3}})*|\\d+)\\s*(?:mi(?:les?)?)/i);
                                if (milesMatch) {{
                                    const miles = parseInt(milesMatch[1].replace(/,/g, ''));
                                    if (miles >= 5000 && miles <= 500000) {{
                                        return {{ found: true, time: depTime, price: miles, type: 'miles', gridId: grid.id }};
                                    }}
                                }}
                            }} else {{
                                // Look for cash price
                                const priceEls = grid.querySelectorAll('.mach-revenue-price__whole');
                                if (priceEls.length > 0) {{
                                    const priceText = priceEls[0].innerText.trim().replace(/,/g, '');
                                    const price = parseInt(priceText);
                                    if (price >= 100 && price <= 10000) {{
                                        return {{ found: true, time: depTime, price: price, type: 'cash', gridId: grid.id }};
                                    }}
                                }}
                            }}
                        }}
                    }}
                    
                    return {{ found: false, debug: 'No match for ' + targetTime }};
                }}""")
                
                print(f"   JS result: {js_result}")
                
                if js_result and js_result.get('found'):
                    target_flight_price = js_result.get('price')
                    found_grid_id = js_result.get('gridId')
                    price_type = js_result.get('type', 'cash')
                    sym = '' if price_type == 'miles' else '$'
                    unit = ' mi' if price_type == 'miles' else ''
                    print(f"   ✓ Found {js_result.get('time')} flight: {sym}{target_flight_price:,}{unit}")
                else:
                    print(f"   ⚠ Could not find {dep_time}, scanning page...")
            
            # Use found price or fallback to page scan
            if target_flight_price:
                price = target_flight_price
            else:
                if use_miles:
                    print("   Scanning for miles...")
                    matches = re.findall(r'([\d,]+)\s*(?:miles?|mi\b)', page_text, re.I)
                    valid = [int(m.replace(',', '')) for m in matches if 5000 <= int(m.replace(',', '')) <= 500000]
                    if valid:
                        price = min(valid)
                        print(f"   Found miles: {sorted(set(valid))[:5]}")
                else:
                    print("   Scanning for cash prices...")
                    matches = re.findall(r'\$\s*([\d,]+)', page_text)
                    valid = [int(m.replace(',', '')) for m in matches if 150 <= int(m.replace(',', '')) <= 5000]
                    if valid:
                        unique = sorted(set(valid))
                        price = unique[1] if exclude_basic and len(unique) >= 2 else unique[0]
                        print(f"   Found prices: {unique[:10]}")
            
            # Take screenshot of specific flight
            if price and take_screenshot:
                try:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    screenshot_file = f"price_{flight_id}_{timestamp}.png"
                    screenshot_path = SCREENSHOTS_DIR / screenshot_file
                    
                    if found_grid_id:
                        # Scroll to and highlight the specific flight
                        page.evaluate(f"""() => {{
                            const grid = document.getElementById('{found_grid_id}');
                            if (grid) {{
                                grid.scrollIntoView({{ behavior: 'instant', block: 'center' }});
                                grid.style.outline = '3px solid #00aa00';
                                grid.style.outlineOffset = '2px';
                            }}
                        }}""")
                        time.sleep(0.5)
                        
                        try:
                            page.locator(f"#{found_grid_id}").screenshot(path=str(screenshot_path))
                            print(f"   📷 Screenshot: {screenshot_file}")
                        except:
                            page.screenshot(path=str(screenshot_path), full_page=False)
                            print(f"   📷 Screenshot (viewport): {screenshot_file}")
                    else:
                        page.evaluate("window.scrollTo(0, 0)")
                        time.sleep(0.3)
                        page.screenshot(path=str(screenshot_path), full_page=False)
                        print(f"   📷 Screenshot: {screenshot_file}")
                except Exception as e:
                    print(f"   Screenshot error: {e}")
            
            context.close()
            browser.close()
            
            if price:
                sym = '' if use_miles else '$'
                unit = ' miles' if use_miles else ''
                print(f"   ✓ Best price: {sym}{price:,}{unit}")
                return price, None, screenshot_file
            else:
                return None, "Could not find price", None
                
        except Exception as e:
            error_msg = str(e)
            print(f"   ❌ Error: {error_msg}")
            try:
                page.screenshot(path=str(debug_png))
                context.close()
                browser.close()
            except:
                pass
            return None, error_msg, None

# =============================================================================
# CHECK ALL FLIGHTS
# =============================================================================

def check_all(headless=True, take_screenshots=True):
    """Check all active scheduled flights."""
    if is_on_cooldown():
        remaining = get_cooldown_remaining()
        print(f"\n⚠️  Auto-check paused ({remaining} remaining)")
        print("   Use manual mode or reset cooldown")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")
    
    # Auto-expire past flights
    c.execute('UPDATE flights SET active=0 WHERE dep_date < ? AND active=1', (today,))
    conn.commit()
    
    # Get active scheduled flights
    try:
        c.execute('''SELECT id, origin, destination FROM flights 
                     WHERE active=1 AND scheduled=1 AND dep_date >= ? ORDER BY dep_date''', (today,))
    except:
        c.execute('''SELECT id, origin, destination FROM flights 
                     WHERE active=1 AND dep_date >= ? ORDER BY dep_date''', (today,))
    
    flights = c.fetchall()
    conn.close()
    
    if not flights:
        print("No active scheduled flights to check.")
        return
    
    print(f"\n{'='*60}")
    print(f"CHECKING {len(flights)} FLIGHT(S)")
    print(f"{'='*60}")
    
    results = []
    for fid, origin, dest in flights:
        price, error, screenshot = check_flight_auto(fid, headless, take_screenshots)
        if price:
            save_price(fid, price, 'auto', screenshot=screenshot)
            results.append((fid, origin, dest, price, None))
        else:
            save_price(fid, None, 'auto', error)
            results.append((fid, origin, dest, None, error))
        
        if is_on_cooldown():
            print("\n⚠️  Bot detection. Stopping.")
            break
        
        # Delay between flights - randomized to avoid bot detection patterns
        if fid != flights[-1][0]:
            # Jitter: 8-30 seconds with occasional longer pauses
            if random.random() < 0.2:  # 20% chance of longer pause
                delay = random.uniform(25, 45)
            else:
                delay = random.uniform(8, 25)
            print(f"\n   Waiting {delay:.0f}s...")
            time.sleep(delay)
    
    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    for fid, origin, dest, price, error in results:
        if price:
            print(f"  ✓ {origin}-{dest}: ${price:,.0f}")
        else:
            print(f"  ✗ {origin}-{dest}: {error or 'Failed'}")

# =============================================================================
# INITIALIZATION
# =============================================================================

init_db()
